// ============================================
// Divesee 文本提取质量测试脚本
// 使用方法：在浏览器控制台直接粘贴运行
// ============================================

(function() {
  console.log('='.repeat(60));
  console.log('📋 Divesee 文本提取质量测试');
  console.log('='.repeat(60));
  
  // 1. 测试文本提取
  console.log('\n【1. 测试文本提取】');
  console.time('提取耗时');
  
  const clone = document.body.cloneNode(true);
  
  // 移除无关元素
  clone.querySelectorAll("script,style,noscript,iframe,nav,header,footer,aside,form,button")
    .forEach(n => n.remove());
  
  // 移除隐藏元素
  clone.querySelectorAll("[hidden],[aria-hidden='true']")
    .forEach(n => n.remove());
  
  // 查找主要内容
  const candidates = [
    "article", "main", "[role='main']",
    ".post,.article,.content,.entry,.post-content,.article-content",
    "#content,#main,#article"
  ];
  
  let node = null;
  for (const sel of candidates) {
    const el = clone.querySelector(sel);
    if (el && el.textContent && el.textContent.trim().length > 200) {
      node = el;
      console.log('✅ 找到主内容区域:', sel);
      break;
    }
  }
  
  if (!node) {
    node = clone;
    console.warn('⚠️ 未找到明确的主内容区域，使用整个body');
  }
  
  // 提取段落
  const paragraphs = [];
  const blockElements = node.querySelectorAll(
    "p,div,article,section,h1,h2,h3,h4,h5,h6,li,blockquote,pre"
  );
  
  console.log('📝 找到块级元素数量:', blockElements.length);
  
  const seen = new Set();
  let skippedNested = 0;
  let skippedShort = 0;
  
  for (const el of blockElements) {
    // 检查是否嵌套
    let isNested = false;
    for (const parent of seen) {
      if (parent.contains(el)) {
        isNested = true;
        skippedNested++;
        break;
      }
    }
    if (isNested) continue;
    
    const text = (el.textContent || "")
      .replace(/\u00A0/g, " ")
      .replace(/[ \t]+/g, " ")
      .replace(/\n+/g, " ")
      .trim();
    
    if (text.length >= 8) {
      paragraphs.push(text);
      seen.add(el);
    } else {
      skippedShort++;
    }
  }
  
  const finalText = paragraphs.join("\n\n");
  
  console.timeEnd('提取耗时');
  console.log('✅ 跳过嵌套元素:', skippedNested);
  console.log('✅ 跳过过短段落:', skippedShort);
  console.log('✅ 有效段落数量:', paragraphs.length);
  console.log('✅ 总文本长度:', finalText.length, '字符');
  
  // 2. 质量分析
  console.log('\n【2. 质量分析】');
  
  const lines = finalText.split('\n\n');
  const avgLength = finalText.length / lines.length;
  const shortParagraphs = lines.filter(l => l.length < 20).length;
  const longParagraphs = lines.filter(l => l.length > 200).length;
  
  console.log('📊 平均段落长度:', Math.round(avgLength), '字符');
  console.log('📊 短段落(<20字):', shortParagraphs);
  console.log('📊 长段落(>200字):', longParagraphs);
  console.log('📊 段落分布:', {
    '极短(<20)': shortParagraphs,
    '短(20-50)': lines.filter(l => l.length >= 20 && l.length < 50).length,
    '中(50-100)': lines.filter(l => l.length >= 50 && l.length < 100).length,
    '长(100-200)': lines.filter(l => l.length >= 100 && l.length < 200).length,
    '极长(>200)': longParagraphs
  });
  
  // 3. 内容预览
  console.log('\n【3. 内容预览】');
  console.log('前3个段落:');
  lines.slice(0, 3).forEach((p, i) => {
    console.log(`\n段落 ${i + 1} (${p.length}字):`);
    console.log(p.substring(0, 100) + (p.length > 100 ? '...' : ''));
  });
  
  // 4. 噪音检测
  console.log('\n【4. 噪音检测】');
  
  const noiseKeywords = [
    '登录', '注册', '关注', '分享', '评论', '点赞',
    '导航', '菜单', '版权所有', '联系我们', '关于我们',
    'Cookie', 'Privacy', 'Terms', '隐私政策', '使用条款',
    '订阅', '推荐阅读', '相关文章', '热门文章', '最新文章'
  ];
  
  const noiseDetected = [];
  for (const keyword of noiseKeywords) {
    const count = (finalText.match(new RegExp(keyword, 'g')) || []).length;
    if (count > 2) {
      noiseDetected.push({ keyword, count });
    }
  }
  
  if (noiseDetected.length > 0) {
    console.warn('⚠️ 检测到可能的噪音词:', noiseDetected);
  } else {
    console.log('✅ 未检测到明显噪音');
  }
  
  // 5. API兼容性测试
  console.log('\n【5. API兼容性测试】');
  
  const MAX_LENGTH = 50000;
  let apiText = finalText;
  
  if (apiText.length > MAX_LENGTH) {
    console.warn('⚠️ 文本超过API限制，将被截断');
    console.log('原始长度:', apiText.length);
    console.log('截断后长度:', MAX_LENGTH);
    apiText = apiText.substring(0, MAX_LENGTH) + '\n\n[文本已截断]';
  } else {
    console.log('✅ 文本长度符合API限制');
  }
  
  const payload = { text: apiText };
  const jsonSize = JSON.stringify(payload).length;
  
  console.log('📦 JSON载荷大小:', jsonSize, '字节 (', (jsonSize / 1024).toFixed(2), 'KB)');
  
  if (jsonSize > 1024 * 1024) {
    console.error('❌ 载荷超过1MB，可能被服务器拒绝');
  } else if (jsonSize > 512 * 1024) {
    console.warn('⚠️ 载荷较大(>512KB)，可能导致请求变慢');
  } else {
    console.log('✅ 载荷大小合理');
  }
  
  // 6. 评分
  console.log('\n【6. 综合评分】');
  
  let score = 100;
  const issues = [];
  
  if (finalText.length < 200) {
    score -= 30;
    issues.push('❌ 文本过短(<200字)');
  }
  
  if (paragraphs.length < 3) {
    score -= 20;
    issues.push('⚠️ 段落数量过少(<3段)');
  }
  
  if (shortParagraphs > paragraphs.length * 0.3) {
    score -= 15;
    issues.push('⚠️ 短段落过多(>30%)');
  }
  
  if (noiseDetected.length > 3) {
    score -= 25;
    issues.push('⚠️ 检测到较多噪音词');
  }
  
  if (avgLength < 30) {
    score -= 10;
    issues.push('⚠️ 平均段落长度过短');
  }
  
  console.log('📊 质量评分:', score, '/ 100');
  
  if (issues.length > 0) {
    console.log('\n🔍 发现的问题:');
    issues.forEach(issue => console.log('  ' + issue));
  } else {
    console.log('✅ 文本质量优秀，无明显问题');
  }
  
  // 7. 建议
  console.log('\n【7. 优化建议】');
  
  if (score >= 80) {
    console.log('🎉 文本提取质量良好，可以直接使用！');
  } else if (score >= 60) {
    console.log('✅ 文本提取基本可用，但建议检查以下问题:');
    if (shortParagraphs > paragraphs.length * 0.3) {
      console.log('  • 考虑增加最小段落长度阈值');
    }
    if (noiseDetected.length > 0) {
      console.log('  • 添加自定义选择器，更精确地定位主内容区域');
    }
  } else {
    console.log('⚠️ 文本提取质量较差，建议:');
    console.log('  • 检查页面是否为单页应用(SPA)，需等待内容加载');
    console.log('  • 添加网站特定的选择器');
    console.log('  • 检查主内容是否在iframe中');
  }
  
  // 8. 导出结果
  console.log('\n【8. 导出结果】');
  console.log('提取的完整文本已保存到 window.diveseeTestResult');
  console.log('使用以下命令查看:');
  console.log('  • 完整文本: console.log(window.diveseeTestResult.fullText)');
  console.log('  • 段落数组: console.log(window.diveseeTestResult.paragraphs)');
  console.log('  • 测试报告: console.log(window.diveseeTestResult.report)');
  
  window.diveseeTestResult = {
    fullText: finalText,
    paragraphs: paragraphs,
    report: {
      score: score,
      textLength: finalText.length,
      paragraphCount: paragraphs.length,
      avgParagraphLength: avgLength,
      shortParagraphs: shortParagraphs,
      longParagraphs: longParagraphs,
      noiseDetected: noiseDetected,
      issues: issues,
      jsonSize: jsonSize
    }
  };
  
  console.log('\n' + '='.repeat(60));
  console.log('✅ 测试完成！');
  console.log('='.repeat(60));
  
})();
