// deepread.content.js
const DR_ATTR = { WRAP:"data-dr-wrap", KEY:"data-dr-key", LOGIC:"data-dr-logic" };
let SETTINGS = null;
let CURRENT_ON = false;
let STOPWORDS = null;
let mo = null;
let ticking = false;
let restored = false;
let autoScrollTimer = null;


// ---- Status Bar (lightweight) ----
let STATUS_TIMER = null;
function ensureStatusBar(){
  let bar = document.getElementById('dr-status');
  if (!bar){
    bar = document.createElement('div');
    bar.id = 'dr-status';
    document.documentElement.appendChild(bar);
  }
  return bar;
}
function showStatus(msg, kind=''){
  const bar = ensureStatusBar();
  bar.textContent = msg || '';
  bar.classList.remove('ok','warn','err','show');
  if (kind) bar.classList.add(kind);
  requestAnimationFrame(()=>{
    bar.classList.add('show');
  });
  clearTimeout(STATUS_TIMER);
  STATUS_TIMER = setTimeout(()=>{ bar.classList.remove('show'); }, 1600);
}
// 统一渲染缓存（支持AI和本地模式）
let RENDER_CACHE = {
  mode: null, // 'ai' or 'local'
  keywords: null, // 关键词数据
  mainSentence: null, // 全文主旨
  paragraphTopics: null, // 段落主题
  aiResult: null // 原始AI结果
};
const PAGE_KEY = location.href + "@" + performance.timeOrigin;
const AI_DONE_KEY = "DR_AI_DONE::" + PAGE_KEY;
const AI_CACHE_KEY = "DR_AI_CACHE::" + PAGE_KEY;
const LOCAL_CACHE_KEY = "DR_LOCAL_CACHE::" + PAGE_KEY;

(async function boot() {
  const cfg = await chrome.storage.sync.get("settings");
  SETTINGS = cfg.settings || {};
  STOPWORDS = await fetchStopwords();

  // 按"默认开启本地算法"初始化
  CURRENT_ON = !!SETTINGS.enabledByDefault;
  if (CURRENT_ON) { enableImmersive(); try{ showStatus('默认开启：本地算法', 'ok'); } catch(e){ try{ showStatus('处理失败', 'err'); }catch(_){} }
}

  // 暴露给面板
  window.DeepReadingAPI = {
getSettings: () => ({ ...SETTINGS }),
    setSettings: (delta) => {
      Object.assign(SETTINGS, delta||{});

      // 互斥：普通模式与 AI 模式不能同时开
      if (SETTINGS.aiEnabled) {
        SETTINGS.mode = "ai";
        if (!CURRENT_ON) CURRENT_ON = true;
      } else {
        SETTINGS.mode = "normal";
      }

      applyGlobalClasses(true);
      applySilentReading(); // 即时根据最新设置调整无声阅读
    },
    enable: () => { CURRENT_ON = true; enableImmersive(); },
    disable: () => { CURRENT_ON = false; disableImmersive(); },
    reset: () => { CURRENT_ON = false; restorePage(true); },
    state: () => ({ 
      enabled: CURRENT_ON, 
      cached: !!RENDER_CACHE.mode,
      mode: RENDER_CACHE.mode
    }),
    rerenderFromCache: () => { 
      // 统一的重新渲染函数，支持AI和本地模式
      if (!RENDER_CACHE.mode) {
        console.warn('[DeepRead] 没有缓存可用');
        return;
      }
      
      if (RENDER_CACHE.mode === 'ai' && RENDER_CACHE.aiResult) {
        applyAIResult(RENDER_CACHE.aiResult);
      } else if (RENDER_CACHE.mode === 'local' && RENDER_CACHE.picked && RENDER_CACHE.units) {
        const LocalAlg = window.DeepReadLocalAlgorithm;
        if (LocalAlg) {
          renderLocalEnhance(RENDER_CACHE.picked, RENDER_CACHE.units, LocalAlg);
        }
      }
    },
    forceRefresh: () => { 
      try { 
        // 清空所有缓存
        RENDER_CACHE = {
          mode: null,
          keywords: null,
          mainSentence: null,
          paragraphTopics: null,
          aiResult: null
        };
        sessionStorage.removeItem(AI_CACHE_KEY); 
        sessionStorage.removeItem(AI_DONE_KEY);
        sessionStorage.removeItem(LOCAL_CACHE_KEY);
        
        // 重新运行分析
        if (SETTINGS.aiEnabled && SETTINGS.apiEndpoint) {
          runAIEnhanceOnce(true);
        } else {
          runLocalEnhance();
        }
      } catch(e){ 
        try{ showStatus('处理失败', 'err'); }catch(_){} 
      }
    },
    update: () => { 
      // 统一的更新函数
      try { 
        // 尝试从缓存恢复
        if (!RENDER_CACHE.mode) {
          const aiCached = sessionStorage.getItem(AI_CACHE_KEY);
          const localCached = sessionStorage.getItem(LOCAL_CACHE_KEY);
          
          if (aiCached) {
            try {
              RENDER_CACHE.aiResult = JSON.parse(aiCached);
              RENDER_CACHE.mode = 'ai';
            } catch(e) {}
          } else if (localCached) {
            try {
              const data = JSON.parse(localCached);
              RENDER_CACHE.mode = 'local';
              RENDER_CACHE.keywords = new Map(data.keywords || []);
              RENDER_CACHE.mainSentence = data.mainSentence;
              RENDER_CACHE.paragraphTopics = data.paragraphTopics;
            } catch(e) {}
          }
        }
        
        // 如果有缓存，重新渲染
        if (RENDER_CACHE.mode) {
          api.rerenderFromCache();
        } else {
          // 没有缓存，重新运行分析
          processOnce();
        }
      } catch(e){ 
        try{ showStatus('处理失败', 'err'); }catch(_){} 
      }
    },
    // 无声阅读控制API
    silentReading: {
      start: () => startSilentReading(),
      pause: () => pauseOrResumeSilentReading(),
      stop: () => stopSilentReading(),
      getState: () => ({
        running: SILENT_READING.running,
        paused: SILENT_READING.paused,
        index: SILENT_READING.idx,
        total: SILENT_READING.sentences.length
      })
    },
    getPageBaseFontSize: () => {
      // 获取页面正文的基本字号（取样本段落的计算字号）
      const candidates = document.querySelectorAll('p, article p, [role="article"] p, .content p, .post p, main p, article, main, .article-content, .post-content');
      let sizes = [];
      
      console.log(`[Font Size Detection] 找到 ${candidates.length} 个候选元素`);
      
      // 收集前几个有内容的元素的字号
      for (let i = 0; i < Math.min(candidates.length, 15); i++) {
        const el = candidates[i];
        // 只统计有实际文本内容的元素
        if (el && el.textContent && el.textContent.trim().length > 20) {
          const computedStyle = window.getComputedStyle(el);
          const computedSize = computedStyle.fontSize;
          const size = parseFloat(computedSize);
          if (size > 0 && size < 100) { // 排除异常值
            sizes.push(size);
            console.log(`[Font Size Detection] 元素 ${i}: ${size}px`);
          }
        }
        if (sizes.length >= 8) break;
      }
      
      if (sizes.length > 0) {
        // 取中位数作为基准字号
        sizes.sort((a, b) => a - b);
        const median = sizes[Math.floor(sizes.length / 2)];
        console.log(`[Font Size Detection] 检测到的字号集合:`, sizes);
        console.log(`[Font Size Detection] 中位数字号: ${median}px`);
        // 返回与浏览器默认 16px 的差值，四舍五入到整数
        const offset = Math.round(median - 16);
        console.log(`[Font Size Detection] 相对于16px的偏移: ${offset}px`);
        return offset;
      }
      
      console.log(`[Font Size Detection] 未检测到有效字号，返回 0`);
      return 0;
    }
};

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "DEEPREAD_ENABLE") { CURRENT_ON = true; enableImmersive(); }
    if (msg?.type === "DEEPREAD_DISABLE") { CURRENT_ON = false; disableImmersive(); }
    if (msg?.type === "DEEPREAD_RESET") { CURRENT_ON = false; restorePage(true); }
    if (msg?.type === "DEEPREAD_APPLY_SETTINGS") {
      Object.assign(SETTINGS, msg.payload||{});
      applyGlobalClasses(true);
      // applyAutoScroll(); // 已废弃，避免报错和额外滚动
    }
  });
})();

async function fetchStopwords() {
  try {
    const res = await fetch(chrome.runtime.getURL("content/stopwords-zh.txt"));
    const txt = await res.text();
    return new Set(txt.split(/\r?\n/).map(s => s.trim()).filter(Boolean));
  } catch { return new Set(["的","了","和","是","在","对","与","及","或","之","着","过","跟","从","向","把","被","且"]); }
}

function enableImmersive() {
  restored = false;
  applyGlobalClasses(true);
  observe();
  processOnce();
  applySilentReading();
}
function disableImmersive() {
  unobserve();
  restorePage(false);
  stopSilentReading();
}
function observe() {
  if (mo) mo.disconnect();
  mo = new MutationObserver(() => { tick(); });
  mo.observe(document.body, { childList:true, subtree:true });
}
function unobserve(){ if (mo){ mo.disconnect(); mo=null; } }
function tick(){
  if (ticking) return;
  ticking = true;
  setTimeout(async ()=>{ await processOnce(); ticking=false; }, 180);
}
async function processOnce(){
  if (!CURRENT_ON || restored) return;
  // 阅读进行中不重跑，避免抖动
  if (SILENT_READING && SILENT_READING.running) return;
  if (SETTINGS.aiEnabled && SETTINGS.apiEndpoint) await runAIEnhanceOnce();
  else if (!AI_RESULT) await runLocalEnhance();
}

function applyGlobalClasses(on) {
  const html=document.documentElement;
  html.classList.toggle("deepread-immersive", !!on);
  html.style.setProperty("--dr-lineHeight", SETTINGS.lineHeight || 1.8);
  // 主题只有普通/深色
  html.classList.toggle("deepread-theme-dark", SETTINGS.immersiveTheme==="dark");

  html.classList.toggle("deepread-focus", !!SETTINGS.focusMode);
  html.classList.toggle("deepread-2col", !!SETTINGS.twoColumn);

  html.classList.toggle("dr-ai-main", SETTINGS.aiHighlightMain !== false);
  html.classList.toggle("dr-ai-topic", SETTINGS.aiMarkParagraphTopics !== false);
  html.classList.toggle("dr-ai-keyword", SETTINGS.aiHighlightKeywords !== false);
  
  // 字号应用：支持正数、负数和0
  if (typeof SETTINGS.fontSizeStep === 'number') {
    if (SETTINGS.fontSizeStep !== 0) {
      html.style.fontSize = `calc(100% + ${SETTINGS.fontSizeStep}px)`;
    } else {
      html.style.fontSize = "";
    }
  } else {
    // 如果没有设置，则不改变字号
    // 不设置为空，避免覆盖用户可能的自定义样式
  }
}

function restorePage(full){
  // 恢复被wrap的文本节点（保留原文，只移除包装）
  document.querySelectorAll(`[${DR_ATTR.WRAP}]`).forEach(w=>{
    const parent=w.parentNode; 
    if(!parent) return;
    
    // 创建文档片段，保留所有子节点（包括文本）
    const frag=document.createDocumentFragment();
    Array.from(w.childNodes).forEach(n=>frag.appendChild(n.cloneNode(true)));
    
    // 替换包装元素，保留原始内容
    parent.replaceChild(frag, w);
    
    // 合并相邻文本节点
    parent.normalize();
  });
  
  // 只移除样式类，不删除元素
  document.querySelectorAll(".dr-key,.dr-logic,.dr-bionic,.dr-main,.dr-topic,.dr-keyword,.dr-underline").forEach(el=>{
    el.classList.remove("dr-key","dr-logic","dr-bionic","dr-main","dr-topic","dr-keyword","dr-underline","dr-on");
    // 移除数据属性
    el.removeAttribute('data-conf');
    el.removeAttribute('data-reason');
  });
  
  if (full) {
    const html=document.documentElement;
    html.classList.remove("deepread-immersive","deepread-focus","deepread-theme-dark","deepread-2col","dr-ai-main","dr-ai-topic","dr-ai-keyword");
    html.style.fontSize="";
    
    // 完全重置时清空缓存
    RENDER_CACHE = {
      mode: null,
      keywords: null,
      mainSentence: null,
      paragraphTopics: null,
      aiResult: null
    };
  }
  restored = true;
}

/* Local heuristic */
function queryParagraphs(){
  const paras=[];
  // 只选择正文内容，排除标题元素
  document.body.querySelectorAll("p,li,blockquote,section,article").forEach(p=>{
    if (!shouldSkip(p)) paras.push(p);
  });
  return paras;
}
function shouldSkip(el){
  if (el.closest("[contenteditable], [data-dr-wrap]")) return true;
  if (el.classList.contains("notranslate")) return true;
  // 排除标题元素（h1-h6）
  if (el.closest("h1, h2, h3, h4, h5, h6")) return true;
  // 排除导航、页眉、页脚等
  if (el.closest("nav, header, footer, aside")) return true;
  return false;
}
function safeText(el){ return (el.innerText||"").replace(/\s+/g," ").trim(); }
function tokenize(text){ return text.match(/[\u4e00-\u9fa5]{1,4}|[A-Za-z]+(?:['-][A-Za-z]+)?|\d+(?:\.\d+)?%?|（[^）]{1,16}）|「[^」]{1,16}」|“[^”]{1,30}”/g)||[]; }
function totalChars(units){ return units.reduce((n,u)=>n+u.text.length,0); }
function rankLocal(units, limit){
  const df=new Map(), scored=[]; const N=units.length;
  units.forEach((u,idx)=>{
    const cand=new Map();
    u.tokens.forEach(t=>{ const k=t.toLowerCase(); if(STOPWORDS.has(k)) return; cand.set(t,(cand.get(t)||0)+1); df.set(k,(df.get(k)||1)+1); });
    const isHeading=/^H[1-3]$/.test(u.el.tagName); const isFirst=idx<Math.max(3,N*0.1), isLast=idx>N*0.9;
    cand.forEach((tf,term)=>{ const idf=Math.log(1+N/(1+(df.get(term.toLowerCase())||1))); let s=tf*idf; if(isHeading)s*=2; if(isFirst||isLast)s*=1.25; if(/^（.+）$|^「.+」$|^“.+”$/.test(term))s*=1.35; if(/^\d/.test(term))s*=1.15; scored.push({term,score:s,para:u}); });
  });
  scored.sort((a,b)=>b.score-a.score);
  const out=[], seen=new Set();
  for(const s of scored){ const norm=s.term.toLowerCase(); if(seen.has(norm)) continue; const same=out.filter(p=>p.para.el===s.para.el); if(same.length>=3) continue; out.push(s); seen.add(norm); if(out.length>=limit) break; }
  return out;
}
async function runLocalEnhance(){
  const paras=queryParagraphs();
  
  // 使用增强的分词算法
  const LocalAlg = window.DeepReadLocalAlgorithm;
  if (!LocalAlg) {
    console.warn('[DeepRead] Local algorithm not loaded, falling back');
    return runLocalEnhanceFallback();
  }
  
  const units=paras.map(p=>({
    el:p,
    text:safeText(p),
    tokens: LocalAlg.enhancedTokenize(safeText(p))
  })).filter(u=>u.text.length>=8);
  
  if (!units.length) return;
  
  // 计算最大关键词数（降低密度：每千字12个，而非24个）
  const maxK = Math.max(6, Math.round(((SETTINGS.maxHighlightsPerK || 12) * totalChars(units)) / 1000));
  
  // 使用增强的TF-IDF评分系统
  const scored = LocalAlg.calculateScores(units, STOPWORDS);
  const picked = LocalAlg.applyMMRAndQuota(scored, maxK);
  
  // 渲染增强效果
  renderLocalEnhance(picked, units, LocalAlg);
  
  // 下划线功能已禁用（保留代码供参考）
  // if (!SETTINGS.silentMode) activateUnderline();
}

// 旧版后备方案
function runLocalEnhanceFallback(){
  const paras=queryParagraphs();
  const units=paras.map(p=>({el:p,text:safeText(p),tokens:tokenize(safeText(p))})).filter(u=>u.text.length>=8);
  if (!units.length) return;
  const maxK=Math.max(6, Math.round(((SETTINGS.maxHighlightsPerK||24)*totalChars(units))/1000));
  const picked=rankLocal(units,maxK);
  renderEnhance(picked, units);
  // 下划线功能已禁用（保留代码供参考）
  // if (!SETTINGS.silentMode) activateUnderline();
}
// 新增:本地算法渲染（支持语义核心提取和缓存）
function renderLocalEnhance(picked, units, LocalAlg){
  // 先清除旧渲染
  clearRenderingEffects();
  
  const byPara=new Map();
  const keywordData = new Map(); // 存储关键词的详细信息（confidence, reason）
  
  // 整理每个段落的关键词
  picked.forEach(p=>{
    if(!byPara.has(p.para.el)) byPara.set(p.para.el,new Set());
    byPara.get(p.para.el).add(p.term);
    keywordData.set(p.term, {
      confidence: p.confidence || 0.5,
      reason: p.reason || "关键词汇"
    });
  });
  
  // 提取语义核心内容（在条件渲染之前）
  let topics = [];
  let mainIdea = null;
  
  try {
    topics = LocalAlg.extractParagraphTopics(units, byPara);
  } catch(e){ console.error('[DeepRead] Topic extraction error:', e); }
  
  try {
    mainIdea = LocalAlg.extractMainIdea(units, picked);
  } catch(e){ console.error('[DeepRead] Main idea extraction error:', e); }
  
  // 缓存结果（用于后续开关控制）
  RENDER_CACHE = {
    mode: 'local',
    keywords: keywordData,
    mainSentence: mainIdea,
    paragraphTopics: topics,
    units: units,
    picked: picked
  };
  
  // 存储到sessionStorage
  try {
    sessionStorage.setItem(LOCAL_CACHE_KEY, JSON.stringify({
      keywords: Array.from(keywordData.entries()),
      mainSentence: mainIdea ? {sentence: mainIdea.sentence, elementIndex: units.findIndex(u => u.el === mainIdea.element)} : null,
      paragraphTopics: topics.map(t => ({sentence: t.sentence, elementIndex: units.findIndex(u => u.el === t.element)}))
    }));
  } catch(e){ console.warn('[DeepRead] Failed to cache local result:', e); }
  
  // 根据开关决定是否高亮关键词
  if (SETTINGS.aiHighlightKeywords !== false) {
    for(const u of units) {
      wrapParagraphWithData(u.el, byPara.get(u.el)||new Set(), keywordData);
    }
  }
  
  // 标记逻辑词
  markLogic();
  
  // 标记关键句块
  if (typeof markKeySentenceBlocks==='function') markKeySentenceBlocks();
  
  // 根据开关提取并标记段落主题句
  if (SETTINGS.aiMarkParagraphTopics !== false && topics.length > 0) {
    topics.forEach(topic => {
      wrapSentenceInElement(topic.element, topic.sentence, "dr-topic");
    });
  }
  
  // 根据开关提取并标记全文主旨句
  if (SETTINGS.aiHighlightMain !== false && mainIdea && mainIdea.sentence) {
    wrapSentenceInElement(mainIdea.element, mainIdea.sentence, "dr-main");
  }
  
  // 初始化关键词悬浮提示
  initKeywordTooltip();
}

// 清除所有渲染效果（不删除原文）
function clearRenderingEffects() {
  // 移除所有已包装的元素（保留文本）
  document.querySelectorAll(`[${DR_ATTR.WRAP}]`).forEach(w=>{
    const parent=w.parentNode;
    if(!parent) return;
    const frag=document.createDocumentFragment();
    Array.from(w.childNodes).forEach(n=>frag.appendChild(n.cloneNode(true)));
    parent.replaceChild(frag, w);
    parent.normalize();
  });
  
  // 清除样式类
  document.querySelectorAll(".dr-key,.dr-logic,.dr-main,.dr-topic,.dr-keyword").forEach(el=>{
    el.classList.remove("dr-key","dr-logic","dr-main","dr-topic","dr-keyword");
    el.removeAttribute('data-conf');
    el.removeAttribute('data-reason');
  });
}

// 旧版渲染（后备）
function renderEnhance(picked, units){
  const byPara=new Map();
  picked.forEach(p=>{ if(!byPara.has(p.para.el)) byPara.set(p.para.el,new Set()); byPara.get(p.para.el).add(p.term); });
  for(const u of units) wrapParagraph(u.el, byPara.get(u.el)||new Set());
  markLogic();
  if (typeof markKeySentenceBlocks==='function') markKeySentenceBlocks();
  try { if (SETTINGS.aiMarkParagraphTopics !== false) markLocalParagraphTopics(units, byPara); } catch(_){}
  try { if (SETTINGS.aiHighlightMain !== false) markLocalMainIdea(units, byPara); } catch(_){}
}
// 带数据属性的关键词包装（用于AI模式悬浮提示）
function wrapParagraphWithData(el, terms, keywordData){
  if (el.hasAttribute(DR_ATTR.WRAP)) return;
  const walker=document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode:(n)=>n.nodeValue.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT });
  const tns=[]; while(walker.nextNode()) tns.push(walker.currentNode);
  const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const pats=Array.from(terms).sort((a,b)=>b.length-a.length).map(esc);
  const re=pats.length?new RegExp(`(${pats.join("|")})`,"g"):null;
  
  for(const tn of tns){
    const raw=tn.nodeValue;
    let html;
    if (re) {
      html=raw.replace(re,(m)=>{
        const data = keywordData.get(m) || {};
        const conf = (data.confidence || 0.5).toFixed(2);
        const reason = data.reason || "关键词汇";
        return `<span class="dr-keyword" ${DR_ATTR.WRAP}="1" data-conf="${conf}" data-reason="${reason}">${m}</span>`;
      });
    } else {
      html=raw;
    }
    const span=document.createElement("span"); span.className="dr-wrap"; span.setAttribute(DR_ATTR.WRAP,"1"); span.innerHTML=html;
    tn.parentNode.replaceChild(span, tn);
  }
}

// 原版包装（无数据属性）
function wrapParagraph(el, terms){
  if (el.hasAttribute(DR_ATTR.WRAP)) return;
  const walker=document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode:(n)=>n.nodeValue.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT });
  const tns=[]; while(walker.nextNode()) tns.push(walker.currentNode);
  const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const pats=Array.from(terms).sort((a,b)=>b.length-a.length).map(esc);
  const re=pats.length?new RegExp(`(${pats.join("|")})`,"g"):null;
  for(const tn of tns){
    const raw=tn.nodeValue; let html;
    if (re) html=raw.replace(re,(m)=>`<span class="dr-keyword" ${DR_ATTR.WRAP}="1">${m}</span>`);
    else html=raw;
    const span=document.createElement("span"); span.className="dr-wrap"; span.setAttribute(DR_ATTR.WRAP,"1"); span.innerHTML=html;
    tn.parentNode.replaceChild(span, tn);
  }
}
function markLogic(){
  const LOGIC=["因此","所以","因为","然而","但是","同时","此外","首先","其次","最后","综上"];
  const esc=s=>s.replace(/[.*+?^${}()|[\\]\\]/g,"\\$&");
  const re=new RegExp(`(${LOGIC.map(esc).join("|")})`,"g");
  document.querySelectorAll(".dr-wrap").forEach(w=>{ w.innerHTML=w.innerHTML.replace(re, `<span class="dr-logic">$1</span>`); });
}

/* 下划线功能（已禁用，保留代码供参考）
function activateUnderline(){
  document.querySelectorAll(".dr-wrap").forEach(w=>{
    if (!w.innerText || w.innerText.length<12) return;
    const html=w.innerHTML.replace(/(.{12,})/g, `<span class="dr-underline">$1</span>`);
    if (html!==w.innerHTML) w.innerHTML=html;
  });
  document.querySelectorAll(".dr-underline").forEach(n=>requestAnimationFrame(()=>n.classList.add("dr-on")));
}
*/

/* AI once */
async function runAIEnhanceOnce(force){
  // ===== 配额检查 =====
  if (window.DeepReadingAPI && window.DeepReadingAPI.checkQuota) {
    if (!window.DeepReadingAPI.checkQuota()) {
      console.warn('[Divesee] 配额不足，无法调用 AI');
      showStatus('调用次数已用完', 'err');
      return;
    }
  }
  
  // 检查缓存
  if (!RENDER_CACHE.aiResult || force) {
    const cached = sessionStorage.getItem(AI_CACHE_KEY);
    if (cached) { 
      try { 
        RENDER_CACHE.aiResult = JSON.parse(cached);
        RENDER_CACHE.mode = 'ai';
      } catch(e) {
        console.warn('[DeepRead] 缓存解析失败:', e);
      }
    }
  }
  
  // 如果有缓存，直接应用
  if (RENDER_CACHE.aiResult) { 
    applyAIResult(RENDER_CACHE.aiResult); 
    return; 
  }
  
  // 防止重复请求
  if (sessionStorage.getItem(AI_DONE_KEY)) return;
  sessionStorage.setItem(AI_DONE_KEY, "1");
  
  let text = collectDocText();
  if (!text || text.length < 50) {
    console.warn('[Divesee] 提取的文本过短，跳过AI分析:', text?.length || 0);
    showStatus('内容过短', 'err');
    return;
  }
  
  // 注意：collectDocText() 已经处理了截断逻辑（在句子/段落边界）
  // 这里只是双重保险检查
  const MAX_TEXT_LENGTH = 80000;  // 80KB
  if (text.length > MAX_TEXT_LENGTH) {
    console.error('[Divesee] 文本仍然过长（不应该发生）:', text.length);
    text = text.substring(0, MAX_TEXT_LENGTH);
  }
  
  console.log('[Divesee] 发送文本到AI分析，长度:', text.length, '字符');
  console.log('[Divesee] 段落数量:', (text.match(/\n\n/g) || []).length + 1);
  console.log('[Divesee] 文本预览:', text.substring(0, 200) + '...');
  
  try {
    showStatus('分析中...', 'ok');
    const res = await fetch(SETTINGS.apiEndpoint.replace(/\/$/,"") + "/api/analyze", {
      method:"POST", 
      headers:{"Content-Type":"application/json"}, 
      body: JSON.stringify({ text })
    });
    
    if (!res.ok) {
      const errorText = await res.text();
      console.error('[Divesee] API返回错误:', res.status, errorText);
      showStatus(`API错误 ${res.status}`, 'err');
      return;
    }
    
    const responseText = await res.text();
    console.log('[Divesee] API响应:', responseText.substring(0, 500));
    
    let aiResult;
    try {
      aiResult = JSON.parse(responseText);
    } catch (parseError) {
      console.error('[Divesee] JSON解析失败:', parseError);
      console.error('[Divesee] 响应内容:', responseText);
      showStatus('响应格式错误', 'err');
      return;
    }
    
    // 验证响应格式
    if (!aiResult || typeof aiResult !== 'object') {
      console.error('[Divesee] 无效的响应格式:', aiResult);
      showStatus('无效响应', 'err');
      return;
    }
    
    console.log('[Divesee] AI分析结果:', {
      main_sentence: aiResult.main_sentence?.substring(0, 50) + '...',
      topics_count: aiResult.paragraph_topic_sentences?.length || 0,
      keywords_count: aiResult.refined_keywords?.length || 0
    });
    
    // ===== AI 调用成功，扣除配额 =====
    if (window.DeepReadingAPI && window.DeepReadingAPI.consumeQuota) {
      window.DeepReadingAPI.consumeQuota();
      console.log('[Divesee] AI 调用成功，已扣除配额');
    }
    
    showStatus('渲染完成', 'ok');
    
    // 应用结果（会自动缓存到RENDER_CACHE）
    applyAIResult(aiResult);
  } catch(e){ 
    console.error('[Divesee] AI分析失败:', e);
    try{ showStatus('处理失败: ' + e.message, 'err'); }catch(_){} 
  }
}
function collectDocText(){
  const clone=document.body.cloneNode(true);
  
  // 1. 移除无关元素
  clone.querySelectorAll("script,style,noscript,iframe,nav,header,footer,aside,form,button").forEach(n=>n.remove());
  
  // 2. 移除隐藏元素（防止提取不可见内容）
  clone.querySelectorAll("[hidden],[aria-hidden='true']").forEach(n=>n.remove());
  const allElements = clone.querySelectorAll("*");
  for (const el of allElements) {
    const style = window.getComputedStyle(document.body.querySelector(el.tagName) || document.body);
    if (style.display === 'none' || style.visibility === 'hidden') {
      el.remove();
    }
  }
  
  // 3. 查找主要内容区域
  const candidates=["article","main","[role='main']", ".post,.article,.content,.entry,.post-content,.article-content","#content,#main,#article"];
  let node=null;
  for(const sel of candidates){ 
    const el=clone.querySelector(sel); 
    if(el && el.textContent && el.textContent.trim().length>200){ 
      node=el; 
      break; 
    } 
  }
  if (!node) node = clone;
  
  // 4. 改进的文本提取：保留段落结构，但跳过标题
  const paragraphs = [];
  const blockElements = node.querySelectorAll("p,div,article,section,li,blockquote,pre");
  
  if (blockElements.length === 0) {
    // 回退：如果没有块级元素，使用textContent
    const text = (node.textContent||"")
      .replace(/\u00A0/g," ")
      .replace(/[ \t]+/g," ")
      .replace(/[ \t]*\n[ \t]*/g,"\n")
      .replace(/\n{3,}/g,"\n\n")
      .trim();
    return text;
  }
  
  // 提取每个块级元素的文本
  const seen = new Set();
  for (const el of blockElements) {
    // 跳过嵌套元素（只取最外层）
    let isNested = false;
    for (const parent of seen) {
      if (parent.contains(el)) {
        isNested = true;
        break;
      }
    }
    if (isNested) continue;
    
    const text = (el.textContent||"")
      .replace(/\u00A0/g," ")
      .replace(/[ \t]+/g," ")
      .replace(/\n+/g," ")
      .trim();
    
    if (text.length >= 10) {  // 增加最小段落长度，避免碎片
      paragraphs.push(text);
      seen.add(el);
    }
  }
  
  // 5. 合并段落，智能截断
  const fullText = paragraphs.join("\n\n");
  const MAX_LENGTH = 80000;  // 增加到80KB
  
  if (fullText.length > MAX_LENGTH) {
    console.warn('[Divesee] 文本过长，智能截断中...', fullText.length, '→', MAX_LENGTH);
    
    // 尝试在句子边界截断
    const truncated = fullText.substring(0, MAX_LENGTH);
    const lastSentenceEnd = Math.max(
      truncated.lastIndexOf('。'),
      truncated.lastIndexOf('！'),
      truncated.lastIndexOf('？'),
      truncated.lastIndexOf('. '),
      truncated.lastIndexOf('! '),
      truncated.lastIndexOf('? ')
    );
    
    if (lastSentenceEnd > MAX_LENGTH * 0.9) {
      // 在句子边界截断（保留90%以上内容）
      console.log('[Divesee] 在句子边界截断，保留', lastSentenceEnd + 1, '字符');
      return truncated.substring(0, lastSentenceEnd + 1);
    }
    
    // 回退：在段落边界截断
    const lastParagraph = truncated.lastIndexOf('\n\n');
    if (lastParagraph > MAX_LENGTH * 0.85) {
      console.log('[Divesee] 在段落边界截断，保留', lastParagraph, '字符');
      return truncated.substring(0, lastParagraph);
    }
    
    // 最后手段：直接截断
    console.warn('[Divesee] 无法在自然边界截断，直接截断');
    return truncated;
  }
  
  return fullText;
}
function applyAIResult(data){
  // 先清除旧渲染
  clearRenderingEffects();
  
  const paras=queryParagraphs();
  
  // 缓存AI结果
  RENDER_CACHE = {
    mode: 'ai',
    keywords: null,
    mainSentence: data.main_sentence || null,
    paragraphTopics: data.paragraph_topic_sentences || [],
    aiResult: data
  };
  
  // 构建关键词数据映射
  const keywordDataMap = new Map();
  if (Array.isArray(data.refined_keywords)) {
    data.refined_keywords.forEach(k => {
      if (typeof k === "string") {
        keywordDataMap.set(k, { confidence: 0.5, reason: "AI识别" });
      } else if (k && k.keyword) {
        keywordDataMap.set(k.keyword, {
          confidence: k.confidence || 0.5,
          reason: k.reason || "AI识别"
        });
      }
    });
    RENDER_CACHE.keywords = keywordDataMap;
  }
  
  // 存储到sessionStorage
  try {
    sessionStorage.setItem(AI_CACHE_KEY, JSON.stringify(data));
  } catch(e){ console.warn('[DeepRead] Failed to cache AI result:', e); }
  
  // 1. 高亮全文主旨（根据开关）
  if (SETTINGS.aiHighlightMain !== false && data.main_sentence) {
    highlightSentenceGlobal(data.main_sentence, "dr-main");
  }
  
  // 2. 标记段落主题（根据开关）
  if (SETTINGS.aiMarkParagraphTopics !== false && Array.isArray(data.paragraph_topic_sentences)){
    data.paragraph_topic_sentences.forEach((s, idx)=>{ 
      if(!s) return; 
      const el=paras[idx]; 
      if(!el) return; 
      wrapSentenceInElement(el, s, "dr-topic"); 
    });
  }
  
  // 3. 高亮关键词（根据开关，带悬浮提示数据）
  if (SETTINGS.aiHighlightKeywords !== false && keywordDataMap.size > 0){
    highlightKeywordsGlobalWithData(keywordDataMap);
  }
  
  // 初始化关键词悬浮提示
  initKeywordTooltip();
}

// 带数据属性的全局关键词高亮（用于AI模式悬浮提示）
function highlightKeywordsGlobalWithData(keywordDataMap){
  if(!keywordDataMap || keywordDataMap.size === 0) return;
  
  const keywords = Array.from(keywordDataMap.keys());
  const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const re=new RegExp(`(${keywords.map(esc).sort((a,b)=>b.length-a.length).join("|")})`,"g");
  
  queryParagraphs().forEach(p=>{
    const walker=document.createTreeWalker(p, NodeFilter.SHOW_TEXT, { 
      acceptNode:(n)=>n.nodeValue.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT 
    });
    const tns=[]; 
    while(walker.nextNode()) tns.push(walker.currentNode);
    
    for(const tn of tns){
      const raw=tn.nodeValue;
      const html=raw.replace(re, (match)=>{
        const data = keywordDataMap.get(match) || {};
        const conf = (data.confidence || 0.5).toFixed(2);
        const reason = data.reason || "AI识别";
        return `<span class="dr-keyword" ${DR_ATTR.WRAP}="1" data-conf="${conf}" data-reason="${reason}">${match}</span>`;
      });
      
      if(html!==raw){ 
        const span=document.createElement("span"); 
        span.className="dr-wrap"; 
        span.setAttribute(DR_ATTR.WRAP,"1"); 
        span.innerHTML=html; 
        tn.parentNode.replaceChild(span, tn); 
      }
    }
  });
  
  markKeySentenceBlocks();
  
  // 初始化关键词悬浮提示
  initKeywordTooltip();
}

function wrapSentenceInElement(el, sentence, cls){
  if (!sentence || !el) return false;
  
  const text = (el.textContent || "");
  const idx = text.indexOf(sentence);
  if (idx < 0) return false;
  
  const start = idx;
  const end = idx + sentence.length;
  
  try {
    // 遍历所有文本节点，找出与目标句子重叠的节点
    const walker = document.createTreeWalker(
      el, 
      NodeFilter.SHOW_TEXT,
      null
    );
    
    const nodesToProcess = [];
    let currentPos = 0;
    
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const nodeLength = node.nodeValue.length;
      const nodeStart = currentPos;
      const nodeEnd = currentPos + nodeLength;
      
      // 检查此节点是否与目标句子重叠
      if (nodeEnd > start && nodeStart < end) {
        const overlapStart = Math.max(0, start - nodeStart);
        const overlapEnd = Math.min(nodeLength, end - nodeStart);
        
        nodesToProcess.push({
          node: node,
          start: overlapStart,
          end: overlapEnd,
          fullyCovered: overlapStart === 0 && overlapEnd === nodeLength
        });
      }
      
      currentPos += nodeLength;
      if (currentPos >= end) break;
    }
    
    if (nodesToProcess.length === 0) return false;
    
    // 反向处理节点（避免DOM变化影响后续节点）
    for (let i = nodesToProcess.length - 1; i >= 0; i--) {
      const {node, start, end, fullyCovered} = nodesToProcess[i];
      
      if (fullyCovered) {
        // 整个文本节点都被覆盖，直接包装
        const wrap = document.createElement('span');
        wrap.className = cls;
        wrap.setAttribute(DR_ATTR.WRAP, "1");
        wrap.textContent = node.nodeValue;
        node.parentNode.replaceChild(wrap, node);
      } else {
        // 部分覆盖，需要分割文本节点
        const before = node.nodeValue.substring(0, start);
        const middle = node.nodeValue.substring(start, end);
        const after = node.nodeValue.substring(end);
        
        const fragment = document.createDocumentFragment();
        
        if (before) {
          fragment.appendChild(document.createTextNode(before));
        }
        
        const wrap = document.createElement('span');
        wrap.className = cls;
        wrap.setAttribute(DR_ATTR.WRAP, "1");
        wrap.textContent = middle;
        fragment.appendChild(wrap);
        
        if (after) {
          fragment.appendChild(document.createTextNode(after));
        }
        
        node.parentNode.replaceChild(fragment, node);
      }
    }
    
    return true;
  } catch (e) {
    console.warn('[Divesee] 句子包装失败:', sentence.substring(0, 30) + '...', e.message);
    return false;
  }
}
function highlightSentenceGlobal(sentence, cls){
  const paras=queryParagraphs();
  for(const p of paras){ if (wrapSentenceInElement(p, sentence, cls)) break; }
}
function highlightKeywordsGlobal(kws){
  if(!kws||!kws.length) return;
  const esc=s=>s.replace(/[.*+?^${}()|[\\]\\]/g,"\\$&");
  const re=new RegExp(`(${kws.map(esc).sort((a,b)=>b.length-a.length).join("|")})`,"g");
  queryParagraphs().forEach(p=>{
    const walker=document.createTreeWalker(p, NodeFilter.SHOW_TEXT, { acceptNode:(n)=>n.nodeValue.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT });
    const tns=[]; while(walker.nextNode()) tns.push(walker.currentNode);
    for(const tn of tns){
      const raw=tn.nodeValue;
      const html=raw.replace(re, `<span class="dr-keyword" ${DR_ATTR.WRAP}="1">$1</span>`);
      if(html!==raw){ 
        const span=document.createElement("span"); 
        span.className="dr-wrap"; 
        span.setAttribute(DR_ATTR.WRAP,"1"); 
        span.innerHTML=html; 
        tn.parentNode.replaceChild(span, tn); 
      }
    }
  });
  markKeySentenceBlocks();
}

function markKeySentenceBlocks(){
  // 只标记正文段落，不包括标题
  const blocks = document.body.querySelectorAll("p,li,blockquote,section,article");
  blocks.forEach(b=>{
    // 跳过标题元素
    if (b.closest("h1, h2, h3, h4, h5, h6")) return;
    if (b.querySelector('.dr-keyword')) b.classList.add('dr-key-sent');
  });
}

/* ========== 关键词悬浮提示系统 ========== */
let tooltipInitialized = false;

function initKeywordTooltip(){
  if (tooltipInitialized) return;
  tooltipInitialized = true;
  
  // 创建提示框元素
  let tooltip = document.getElementById('dr-keyword-tooltip');
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.id = 'dr-keyword-tooltip';
    tooltip.className = 'dr-tooltip';
    tooltip.style.cssText = `
      position: fixed;
      display: none;
      background: rgba(15, 23, 42, 0.95);
      color: #fff;
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 13px;
      line-height: 1.6;
      max-width: 280px;
      z-index: 2147483647;
      pointer-events: none;
      box-shadow: 0 8px 24px rgba(0,0,0,0.35);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    `;
    document.body.appendChild(tooltip);
  }
  
  // 监听鼠标移动
  document.addEventListener('mousemove', handleKeywordHover, true);
  document.addEventListener('mouseout', handleKeywordLeave, true);
}

function handleKeywordHover(e){
  const target = e.target;
  
  // 检查是否是关键词元素
  if (!target.classList.contains('dr-keyword')) {
    hideTooltip();
    return;
  }
  
  // 获取关键词数据
  const keyword = target.textContent;
  const conf = target.getAttribute('data-conf');
  const reason = target.getAttribute('data-reason');
  
  // 如果没有数据属性，不显示提示
  if (!conf && !reason) {
    hideTooltip();
    return;
  }
  
  // 构建提示内容
  const tooltip = document.getElementById('dr-keyword-tooltip');
  if (!tooltip) return;
  
  const confValue = conf ? parseFloat(conf).toFixed(2) : '0.50';
  const reasonText = reason || '— 无理由 —';
  
  tooltip.innerHTML = `
    <div style="font-weight: 700; margin-bottom: 6px; color: #60a5fa;">
      关键词：${keyword}
    </div>
    <div style="margin-bottom: 4px; font-size: 12px;">
      <span style="opacity: 0.8;">置信理由：</span>${reasonText}
    </div>
    <div style="font-size: 12px;">
      <span style="opacity: 0.8;">置信度：</span><span style="color: #34d399;">${confValue}</span>
    </div>
  `;
  
  // 定位提示框
  const x = e.clientX + 12;
  const y = e.clientY + 12;
  
  tooltip.style.left = x + 'px';
  tooltip.style.top = y + 'px';
  tooltip.style.display = 'block';
  
  // 防止提示框超出视口
  requestAnimationFrame(() => {
    const rect = tooltip.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    if (rect.right > viewportWidth) {
      tooltip.style.left = (viewportWidth - rect.width - 12) + 'px';
    }
    if (rect.bottom > viewportHeight) {
      tooltip.style.top = (viewportHeight - rect.height - 12) + 'px';
    }
  });
}

function handleKeywordLeave(e){
  const target = e.target;
  const relatedTarget = e.relatedTarget;
  
  // 如果鼠标移出关键词元素
  if (target.classList.contains('dr-keyword')) {
    // 检查是否移动到另一个关键词上
    if (!relatedTarget || !relatedTarget.classList.contains('dr-keyword')) {
      hideTooltip();
    }
  }
}

function hideTooltip(){
  const tooltip = document.getElementById('dr-keyword-tooltip');
  if (tooltip) {
    tooltip.style.display = 'none';
  }
}



function sentencesOf(text){
  return text.split(/(?<=[。！？!?；;])/).map(s=>s.trim()).filter(Boolean);
}
function markLocalParagraphTopics(units, byPara){
  try{
    if (!Array.isArray(units)) return;
    units.forEach(u=>{
      const termSet = byPara.get(u.el) || new Set();
      if (!termSet.size) return;
      const sents = sentencesOf(u.text);
      let best = ""; let bestScore = 0;
      sents.forEach(s=>{
        let score = 0;
        termSet.forEach(t=>{ if (s.includes(t)) score += t.length; });
        if (score > bestScore){ bestScore = score; best = s; }
      });
      if (best) wrapSentenceInElement(u.el, best, "dr-topic");
    });
  }catch(_){}
}
function markLocalMainIdea(units, byPara){
  try{
    const global = new Map();
    byPara.forEach(set=>set.forEach(t=> global.set(t, (global.get(t)||0)+1)));
    const topTerms = Array.from(global.entries()).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([t])=>t);
    let best = {s:"", score: 0, el:null};
    units.forEach(u=>{
      const sents = sentencesOf(u.text);
      sents.forEach(s=>{
        let sc = 0; topTerms.forEach(t=>{ if (s.includes(t)) sc += t.length; });
        if (sc > best.score){ best = {s, score: sc, el:u.el}; }
      });
    });
    if (best.el && best.s) wrapSentenceInElement(best.el, best.s, "dr-main");
  }catch(_){}
}

/* ========== 无声阅读系统（逐句高亮） ========== */

// 无声阅读状态
const SILENT_READING = {
  running: false,      // 是否正在运行
  paused: false,       // 是否暂停
  timer: null,         // 定时器
  idx: 0,              // 当前句子索引
  sentences: [],       // 句子列表
  elements: []         // 句子对应的DOM元素
};

// 初始化无声阅读
function initSilentReading() {
  // 始终收集句子，不再检查silentMode开关
  collectSentences();
  
  // 如果有句子，准备就绪
  if (SILENT_READING.sentences.length > 0) {
    console.log('[Silent Reading] 初始化完成，共', SILENT_READING.sentences.length, '个句子');
  }
}

// 收集页面中的所有句子
function collectSentences() {
  SILENT_READING.sentences = [];
  SILENT_READING.elements = [];
  
  const paras = queryParagraphs();
  
  paras.forEach(p => {
    const text = safeText(p);
    if (!text || text.length < 5) return;
    
    // 按句子分割（基于标点符号）
    const sents = text.split(/(?<=[。！？!?；;])/);
    
    sents.forEach(sent => {
      const trimmed = sent.trim();
      if (trimmed.length >= 5) {
        SILENT_READING.sentences.push(trimmed);
        SILENT_READING.elements.push(p);
      }
    });
  });
}

// 开始无声阅读
function startSilentReading() {
  // 重新收集句子（确保最新）
  collectSentences();
  
  if (SILENT_READING.sentences.length === 0) {
    console.warn('[Silent Reading] 没有可阅读的句子');
    showStatus('没有可阅读内容', 'warn');
    return;
  }
  
  // 重置状态
  SILENT_READING.idx = 0;
  SILENT_READING.running = true;
  SILENT_READING.paused = false;
  
  console.log('[Silent Reading] 开始阅读，共', SILENT_READING.sentences.length, '个句子');
  showStatus('开始无声阅读', 'ok');
  
  // 开始第一句
  tickSentence();
}

// 暂停或继续
function pauseOrResumeSilentReading() {
  if (!SILENT_READING.running) {
    // 如果未开始，则开始
    startSilentReading();
    return;
  }
  
  SILENT_READING.paused = !SILENT_READING.paused;
  
  if (!SILENT_READING.paused) {
    // 继续
    console.log('[Silent Reading] 继续阅读');
    showStatus('继续阅读', 'ok');
    tickSentence();
  } else {
    // 暂停
    console.log('[Silent Reading] 暂停阅读');
    showStatus('已暂停', 'warn');
    clearTimeout(SILENT_READING.timer);
    SILENT_READING.timer = null;
  }
}

// 停止无声阅读
function stopSilentReading() {
  clearTimeout(SILENT_READING.timer);
  SILENT_READING.timer = null;
  SILENT_READING.idx = 0;
  SILENT_READING.running = false;
  SILENT_READING.paused = false;
  
  // 移除所有高亮
  document.querySelectorAll('.dr-sentence-active').forEach(el => {
    el.classList.remove('dr-sentence-active');
  });
  
  console.log('[Silent Reading] 停止阅读');
  showStatus('已停止', 'warn');
}

// 逐句阅读的tick函数
function tickSentence() {
  if (!SILENT_READING.running || SILENT_READING.paused) return;
  
  // 检查是否读完
  if (SILENT_READING.idx >= SILENT_READING.sentences.length) {
    console.log('[Silent Reading] 阅读完成');
    showStatus('阅读完成', 'ok');
    stopSilentReading();
    return;
  }
  
  // 高亮当前句子
  const success = focusSentence(SILENT_READING.idx);
  if (!success) {
    // 如果句子定位失败，跳到下一句
    SILENT_READING.idx++;
    tickSentence();
    return;
  }
  
  // 计算当前句子的停留时间
  const text = SILENT_READING.sentences[SILENT_READING.idx];
  const wpm = Math.max(120, Number(SETTINGS.wpm || 480)); // 默认480字/分钟
  const cps = wpm / 60; // 字/秒
  const dur = Math.max(0.6, Math.min(6, text.length / cps)); // 停留时间（秒）
  
  console.log(`[Silent Reading] 句子 ${SILENT_READING.idx + 1}/${SILENT_READING.sentences.length}: "${text.substring(0, 20)}..." (${text.length}字, ${dur.toFixed(1)}秒)`);
  
  // 移动到下一句
  SILENT_READING.idx++;
  
  // 设置定时器
  SILENT_READING.timer = setTimeout(tickSentence, dur * 1000);
}

// 高亮并定位到指定句子
function focusSentence(idx) {
  // 移除之前的高亮
  document.querySelectorAll('.dr-sentence-active').forEach(el => {
    el.classList.remove('dr-sentence-active');
  });
  
  if (idx >= SILENT_READING.sentences.length) return false;
  
  const sentence = SILENT_READING.sentences[idx];
  const element = SILENT_READING.elements[idx];
  
  if (!element) return false;
  
  // 在元素中查找并高亮句子
  const text = element.textContent || element.innerText;
  const sentIdx = text.indexOf(sentence);
  
  if (sentIdx === -1) {
    // 句子未找到，尝试模糊匹配
    const normalized = text.replace(/\s+/g, '');
    const normalizedSent = sentence.replace(/\s+/g, '');
    if (normalized.includes(normalizedSent)) {
      // 整段高亮
      element.classList.add('dr-sentence-active');
      scrollToElement(element);
      return true;
    }
    return false;
  }
  
  // 精确匹配：包装句子
  try {
    wrapSentenceInElement(element, sentence, 'dr-sentence-active');
    // 滚动到句子包装器，而非整段元素
    const target = element.querySelector('.dr-sentence-active') || element;
    scrollToElement(target);
    return true;
  } catch (e) {
    console.warn('[Silent Reading] 句子高亮失败:', e);
    // 回退：整段高亮
    element.classList.add('dr-sentence-active');
    scrollToElement(element);
    return true;
  }
}

// 滚动到指定元素
function scrollToElement(el) {
  if (!el) return;
  
  try {
    el.scrollIntoView({ 
      behavior: 'smooth', 
      block: 'center',
      inline: 'nearest'
    });
  } catch (e) {
    // 回退方案
    const rect = el.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const targetY = rect.top + scrollTop - (window.innerHeight / 2) + (rect.height / 2);
    window.scrollTo({ top: targetY, behavior: 'smooth' });
  }
}

// 应用无声阅读设置
function applySilentReading() {
  // 始终初始化，不再检查silentMode
  initSilentReading();
}

/* 废弃旧的自动滚动系统（保留供参考）
function applyAutoScroll(){
  clearAutoScroll();

  // 仅在“开启沉浸阅读”且“无声阅读=开”时，根据速度滚动
  if (!CURRENT_ON) return;
  if (!SETTINGS.silentMode) return;

  const wpm = Math.max(0, Number(SETTINGS.wpm||0));
  if (!wpm) return;

  const sample=document.querySelector("article p, main p, .content p, p");
  let pxPerChar=0.4;
  if(sample){
    const chars=(sample.innerText||"").length;
    const h=Math.max(1, sample.getBoundingClientRect().height);
    const lineH=parseFloat(getComputedStyle(sample).lineHeight)||22;
    const lines=Math.max(1, h/lineH);
    const charsPerLine=Math.max(1, chars/lines);
    pxPerChar=lineH/charsPerLine; if(!isFinite(pxPerChar)||pxPerChar<=0) pxPerChar=0.4;
  }
  const pxPerMin=wpm*pxPerChar, pxPerSec=pxPerMin/60;
  const step=Math.max(1, Math.round(pxPerSec/10));
  autoScrollTimer=setInterval(()=>window.scrollBy(0, step), 100);
}
function clearAutoScroll(){ if(autoScrollTimer){ clearInterval(autoScrollTimer); autoScrollTimer=null; } }
*/


// --- Safety: ensure update/forceRefresh exist on API ---
try{
  if (window.DeepReadingAPI && !window.DeepReadingAPI.update){
    window.DeepReadingAPI.update = ()=>{
      try{
        if (!AI_RESULT) {
          const cached = sessionStorage.getItem(AI_CACHE_KEY);
          if (cached) AI_RESULT = JSON.parse(cached);
        }
        if (AI_RESULT) applyAIResult(AI_RESULT);
      }catch(e){ try{ showStatus('处理失败','err'); }catch(_){} }
    };
  }
  if (window.DeepReadingAPI && !window.DeepReadingAPI.forceRefresh){
    window.DeepReadingAPI.forceRefresh = ()=>{
      try {
        AI_RESULT = null;
        sessionStorage.removeItem(AI_CACHE_KEY);
        sessionStorage.removeItem(AI_DONE_KEY);
        runAIEnhanceOnce(true);
      } catch(e){ try{ showStatus('处理失败','err'); }catch(_){} }
    };
  }
}catch(_){}
