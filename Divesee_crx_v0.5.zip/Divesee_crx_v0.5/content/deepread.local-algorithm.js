// deepread.local-algorithm.js
// 增强的本地语义分析系统

/* ========== 词典和规则库 ========== */

// 扩展停用词列表
const EXTENDED_STOPWORDS = new Set([
  "的","了","和","是","在","对","与","及","或","之","着","过","跟","从","向","把","被","且",
  "这","那","些","此","就","都","而","也","个","为","有","到","以","上","中","下","里","得",
  "于","等","与其","并且","但是","然而","因此","所以","如果","虽然","尽管","无论","不管",
  "可以","能够","应该","需要","必须","可能","也许","大概","大约","左右","通过","根据","按照",
  "关于","对于","由于","因为","为了","作为","成为","变成","进行","实现","达到","得到","获得",
  "一个","一些","几个","很多","非常","比较","更加","最","越","更","太","十分","极","特别",
  "什么","怎么","如何","为何","哪里","哪些","谁","其","其中","其它","另外","此外","而且",
  "不","没","无","未","否","别","勿","莫","毋","非","弗","曾","将","会","要","想","让","叫"
]);

// 中文词性权重
const POS_WEIGHTS = {
  noun: 1.5,        // 名词
  verb: 1.0,        // 动词
  adj: 1.2,         // 形容词
  proper: 2.0,      // 专有名词
  entity: 2.5,      // 命名实体
  tech: 2.2,        // 技术术语
  number: 1.3       // 数字+单位
};

// 命名实体识别模式（NER）
const NER_PATTERNS = {
  person: /(?:^|[\s，。；！？])([张王李赵刘陈杨黄吴周徐孙马朱胡郭何高林罗郑梁宋谢唐韩冯于董萧程曹袁邓许傅沈曾彭吕苏卢蒋蔡贾丁魏薛叶阎余潘杜戴夏钟汪田任姜范方石姚谭廖邹熊金陆郝孔白崔康毛邱秦江史顾侯邵孟龙万段雷钱汤尹黎易常武乔贺赖龚文][一-龥]{1,3})(?=[\s，。；！？]|$)/g,
  place: /([北上广深京沪津渝][一-龥]{0,2}[市区县镇村路街道]|[一-龥]{2,4}(?:省|市|县|区|镇|村|路|街|道|公司|大学|学院|医院|银行|集团))/g,
  org: /([一-龥]{2,8}(?:公司|集团|企业|机构|协会|学会|基金会|研究院|研究所|大学|学院|中心|部门|委员会))/g,
  tech: /([A-Z]{2,}|[A-Z][a-z]+(?:[A-Z][a-z]+)*|[\u4e00-\u9fa5]{2,4}(?:算法|模型|系统|技术|方法|理论|原理))/g
};

// 逻辑词（用于标记）
const LOGIC_WORDS = [
  "因此","所以","因为","由于","然而","但是","不过","可是","同时","此外","而且",
  "首先","其次","再次","最后","综上","总之","总而言之","换句话说","也就是说",
  "例如","比如","譬如","假设","假如","如果","那么","则","否则"
];

/* ========== 分词和词性分析 ========== */

// 增强的中文分词
function enhancedTokenize(text) {
  const tokens = new Set();
  
  // 1. 命名实体提取
  Object.values(NER_PATTERNS).forEach(pattern => {
    const matches = text.match(pattern) || [];
    matches.forEach(m => tokens.add(m.trim()));
  });
  
  // 2. 3-6字的中文词组（过滤2字泛词）
  const chineseWords = text.match(/[\u4e00-\u9fa5]{3,6}/g) || [];
  chineseWords.forEach(w => tokens.add(w));
  
  // 3. 引用内容已禁用（减少噪音）
  // const quotes = text.match(/["""「」『』《》〈〉【】〔〕（）][^"""「」『』《》〈〉【】〔〕（）]{1,30}["""「」『』《》〈〉【】〔〕（）]/g) || [];
  // quotes.forEach(q => tokens.add(q));
  
  // 4. 英文单词
  const englishWords = text.match(/[A-Z]?[a-z]+(?:['-][A-Za-z]+)*/g) || [];
  englishWords.forEach(w => {
    if(w.length >= 3) tokens.add(w);
  });
  
  // 5. 数字+单位
  const numbers = text.match(/\d+(?:\.\d+)?[年月日天小时分钟秒元块毛角分厘千万亿兆%‰度米厘米毫米千米吨千克克毫克升毫升]/g) || [];
  numbers.forEach(n => tokens.add(n));
  
  // 6. 中英混合词
  const mixed = text.match(/[A-Za-z]+[\u4e00-\u9fa5]+|[\u4e00-\u9fa5]+[A-Za-z]+/g) || [];
  mixed.forEach(m => tokens.add(m));
  
  // 7. 专业术语（含特殊符号）
  const technical = text.match(/[A-Z]{2,}(?:-[A-Z0-9]+)?|\b[A-Za-z]+\d+/g) || [];
  technical.forEach(t => tokens.add(t));
  
  return Array.from(tokens);
}

// 词性识别
function analyzePOS(term) {
  // 命名实体
  for(const [type, pattern] of Object.entries(NER_PATTERNS)){
    if(pattern.test(term)) return 'entity';
  }
  
  // 专有名词（大写开头）
  if (/^[A-Z][a-z]+/.test(term)) return 'proper';
  
  // 技术术语
  if (/[A-Z]{2,}/.test(term) || /[\u4e00-\u9fa5]{2,4}(?:算法|模型|系统|技术|方法|理论|原理|平台|框架)/.test(term)) {
    return 'tech';
  }
  
  // 数字+单位
  if (/^\d+(?:\.\d+)?[年月日天小时分钟秒元块毛角分千万亿%‰]/.test(term)) {
    return 'number';
  }
  
  // 形容词后缀
  if (/[性化的能]$/.test(term) && term.length >= 3) return 'adj';
  
  // 动词后缀
  if (/[化]$/.test(term) && term.length >= 2) return 'verb';
  
  // 默认为名词
  return 'noun';
}

/* ========== TF-IDF和综合评分 ========== */

// 计算TF-IDF和综合评分
function calculateScores(units, stopwords) {
  const df = new Map();
  const scored = [];
  const N = units.length;
  const allStopwords = new Set([...stopwords, ...EXTENDED_STOPWORDS]);
  
  // 第一遍：统计文档频率
  units.forEach((u, idx) => {
    const termFreq = new Map();
    
    u.tokens.forEach(t => {
      const k = t.toLowerCase();
      
      // 过滤规则
      if (allStopwords.has(k)) return;
      if (t.length === 1) return;
      if (/^[的了吗呢啊吧呀哦哈嗯额]/.test(t)) return;
      
      termFreq.set(t, (termFreq.get(t) || 0) + 1);
      df.set(k, (df.get(k) || 0) + 1);
    });
    
    u.termFreq = termFreq;
  });
  
  // 第二遍：计算综合评分
  units.forEach((u, idx) => {
    const isHeading = /^H[1-6]$/.test(u.el.tagName);
    const isTitle = idx === 0 || isHeading;
    const isFirst = idx < Math.max(3, N * 0.1);
    const isLast = idx > N * 0.85;
    const isList = u.el.tagName === 'LI';
    
    u.termFreq.forEach((tf, term) => {
      const k = term.toLowerCase();
      const docFreq = df.get(k) || 1;
      
      // 基础TF-IDF
      const idf = Math.log((1 + N) / (1 + docFreq));
      const tfidf = tf * idf;
      
      // Z-score归一化
      const avgTf = Array.from(u.termFreq.values()).reduce((a,b)=>a+b,0) / u.termFreq.size;
      const zScore = tf > avgTf ? (tf - avgTf) / Math.max(avgTf, 1) : 0;
      
      // 词性权重
      const pos = analyzePOS(term);
      const posWeight = POS_WEIGHTS[pos] || 1.0;
      
      // 位置先验
      let positionPrior = 1.0;
      if (isTitle) positionPrior = 2.5;
      else if (isHeading) positionPrior = 2.0;
      else if (isFirst) positionPrior = 1.5;
      else if (isLast) positionPrior = 1.3;
      else if (isList) positionPrior = 1.2;
      
      // 特殊格式加权
      let formatBoost = 1.0;
      if (/^["""「」『』《》〈〉【】].+["""「」『』《》〈〉【】]$/.test(term)) formatBoost = 1.4;
      else if (/^（.+）$/.test(term)) formatBoost = 1.25;
      else if (/^\d/.test(term)) formatBoost = 1.3;
      
      // 长度惩罚
      let lengthPenalty = 1.0;
      if (term.length < 2) lengthPenalty = 0.3;
      else if (term.length === 2) lengthPenalty = 0.8;
      else if (term.length > 8) lengthPenalty = 0.7;
      
      // 综合评分公式
      // S = α·tfidf + β·zScore + γ·posWeight + δ·positionPrior + ε·formatBoost - η·lengthPenalty
      const score = (
        0.3 * tfidf +
        0.2 * zScore +
        0.2 * posWeight +
        0.2 * positionPrior +
        0.1 * formatBoost
      ) * lengthPenalty;
      
      scored.push({
        term,
        score,
        para: u,
        pos,
        tf,
        idf,
        paraIndex: idx,
        distribution: docFreq,
        confidence: Math.min(score / 5, 1.0),
        reason: generateReason(term, pos, positionPrior, formatBoost, docFreq)
      });
    });
  });
  
  return scored;
}

// 生成关键词选择理由
function generateReason(term, pos, positionPrior, formatBoost, distribution) {
  const reasons = [];
  
  if (pos === 'entity') reasons.push('命名实体');
  else if (pos === 'tech') reasons.push('技术术语');
  else if (pos === 'proper') reasons.push('专有名词');
  
  if (positionPrior >= 2.0) reasons.push('标题关键信息');
  else if (positionPrior >= 1.5) reasons.push('重要位置');
  
  if (formatBoost > 1.3) reasons.push('特殊标记');
  
  if (distribution >= 3) reasons.push('多处出现');
  else if (distribution >= 2) reasons.push('重复提及');
  
  if (term.length >= 4) reasons.push('完整术语');
  
  return reasons.length > 0 ? reasons.join('，') : '高频词汇';
}

/* ========== MMR去重和配额控制 ========== */

function applyMMRAndQuota(scored, limit) {
  // 排序
  scored.sort((a, b) => b.score - a.score);
  
  const selected = [];
  const seen = new Set();
  const paraCount = new Map();
  
  for (const item of scored) {
    const norm = item.term.toLowerCase();
    
    // 去重
    if (seen.has(norm)) continue;
    
    // 检查相似性（子串或包含关系）
    let hasSimilar = false;
    for (const existing of selected) {
      const existingNorm = existing.term.toLowerCase();
      
      // 如果一个词是另一个词的子串
      if (existingNorm.includes(norm) || norm.includes(existingNorm)) {
        // 保留更长、更完整的词
        if (norm.length > existingNorm.length) {
          const idx = selected.indexOf(existing);
          selected.splice(idx, 1);
          seen.delete(existingNorm);
        } else {
          hasSimilar = true;
          break;
        }
      }
    }
    
    if (hasSimilar) continue;
    
    // 只保留高价值词性（entity/tech/proper）
    const allowedPOS = ['entity', 'tech', 'proper'];
    if (!allowedPOS.includes(item.pos)) continue;
    
    // 每个段落最多2个关键词（拥挤风险控制）
    const paraKey = item.para.el;
    const count = paraCount.get(paraKey) || 0;
    if (count >= 2) continue;
    
    // 分布广度检查（要求既有分布又有高分）
    if (item.distribution >= 2 && item.score > (scored[0]?.score || 0) * 0.35) {
      selected.push(item);
      seen.add(norm);
      paraCount.set(paraKey, count + 1);
    }
    
    // 配额控制
    if (selected.length >= limit) break;
  }
  
  return selected;
}

/* ========== 语义核心提取 ========== */

// 提取段落主题句
function extractParagraphTopics(units, keywordsByPara) {
  const topics = [];
  
  units.forEach(u => {
    const keywords = keywordsByPara.get(u.el) || new Set();
    if (keywords.size === 0) return;
    
    const sentences = splitSentences(u.text);
    let bestSent = "";
    let bestScore = 0;
    
    sentences.forEach(sent => {
      let score = 0;
      
      // 关键词匹配
      keywords.forEach(kw => {
        if (sent.includes(kw)) {
          score += kw.length * 2;
        }
      });
      
      // 位置加权（首句优先）
      if (sent === sentences[0]) score *= 1.5;
      
      // 长度合理性（不要太短或太长）
      if (sent.length < 10 || sent.length > 100) score *= 0.5;
      
      if (score > bestScore) {
        bestScore = score;
        bestSent = sent;
      }
    });
    
    if (bestSent && bestScore > 0) {
      topics.push({
        sentence: bestSent,
        element: u.el,
        score: bestScore
      });
    }
  });
  
  return topics;
}

// 提取全文主旨句
function extractMainIdea(units, allKeywords) {
  // 统计全局高频关键词
  const globalFreq = new Map();
  allKeywords.forEach(kw => {
    globalFreq.set(kw.term, (globalFreq.get(kw.term) || 0) + 1);
  });
  
  // 取top关键词
  const topTerms = Array.from(globalFreq.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([term]) => term);
  
  let best = { sentence: "", score: 0, element: null };
  
  units.forEach((u, idx) => {
    const sentences = splitSentences(u.text);
    const isFirst = idx < units.length * 0.2;
    const isLast = idx > units.length * 0.8;
    
    sentences.forEach(sent => {
      let score = 0;
      
      // 关键词覆盖
      topTerms.forEach(term => {
        if (sent.includes(term)) {
          score += term.length * 1.5;
        }
      });
      
      // 位置权重（首尾段落优先）
      if (isFirst) score *= 2.0;
      else if (isLast) score *= 1.5;
      
      // 句子长度合理性
      if (sent.length < 15 || sent.length > 150) score *= 0.6;
      else if (sent.length >= 30 && sent.length <= 80) score *= 1.2;
      
      // 逻辑词加权
      if (/因此|所以|综上|总之|总而言之/.test(sent)) score *= 1.3;
      
      if (score > best.score) {
        best = { sentence: sent, score, element: u.el };
      }
    });
  });
  
  return best.sentence ? best : null;
}

// 分句
function splitSentences(text) {
  return text
    .split(/[。！？；!?;]/)
    .map(s => s.trim())
    .filter(s => s.length >= 5);
}

/* ========== 导出API ========== */

window.DeepReadLocalAlgorithm = {
  enhancedTokenize,
  calculateScores,
  applyMMRAndQuota,
  extractParagraphTopics,
  extractMainIdea,
  LOGIC_WORDS
};
