// deepread.panel.js
(function(){
  const ready = ()=> new Promise(r => {
    const t = setInterval(()=>{ if (window.DeepReadingAPI) { clearInterval(t); r(); } }, 50);
  });
  ready().then(init);

  function init(){
    const api = window.DeepReadingAPI;
    const S = api.getSettings();

    // Root + Shadow
    const root = document.createElement('div');
    root.id = 'dr-overlay-root';
    root.style.position = 'fixed';
    root.style.zIndex = 2147483646;
    root.style.inset = '24px 24px auto auto'; // default 右上角
    document.documentElement.appendChild(root);
    const shadow = root.attachShadow({ mode: 'open' });

    const create = (html)=>{
      const el = document.createElement('div');
      el.innerHTML = html.trim();
      return el.firstElementChild;
    };

    // Floating Button（玻璃拟态）
    const fab = create(`<button title="潜读控制台"><img src="${chrome.runtime.getURL('assets/icon-48.png')}" style="width:100%;height:100%;border-radius:50%;" alt="D"></button>`);
    Object.assign(fab.style, {
      position:'fixed', width:'48px', height:'48px',
      right:'24px', top:'24px',
      borderRadius:'50%', border:'1px solid rgba(15,23,42,.08)',
      cursor:'pointer', fontWeight:'700', fontSize:'18px',
      boxShadow:'0 8px 24px rgba(0,0,0,.25)',
      backdropFilter:'saturate(160%) blur(12px)', WebkitBackdropFilter:'saturate(160%) blur(12px)',
      padding:'0', overflow:'hidden'
    });
    shadow.appendChild(fab);

    // Panel container（玻璃拟态）
    const panel = create(`<div id="panel" style="display:none"></div>`);
    Object.assign(panel.style, {
      position:'fixed', minWidth:'340px', maxWidth:'380px', maxHeight:'70vh', overflow:'auto',
      borderRadius:'16px', padding:'12px 12px 14px 12px',
      boxShadow:'0 16px 40px rgba(0,0,0,.32)'
    });

    panel.innerHTML = `
      <style>
        :host{ all: initial; font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "PingFang SC","Microsoft YaHei","Noto Sans CJK SC", sans-serif; }
        #panel{ border:1px solid transparent; backdrop-filter:saturate(160%) blur(14px); -webkit-backdrop-filter:saturate(160%) blur(14px); }
        /* 主题：玻璃拟态（浅/深） */
        #panel[data-theme="light"]{ background:rgba(248,250,252,.55); color:#0f172a; border-color:rgba(15,23,42,.08); }
        #panel[data-theme="dark"]{  background:rgba(11,18,32,.55);  color:#e5edff; border-color:rgba(255,255,255,.12); }

        .row{display:flex;align-items:center;justify-content:space-between;margin:8px 0;gap:10px}
        .group{margin-top:10px;padding-top:10px}
        .title{font-weight:700;margin-bottom:6px}
        .hint{font-size:11px;opacity:.7}
        .divider{height:1px;margin:10px -12px}
        #panel[data-theme="light"] .divider{background:rgba(15,23,42,.08)}
        #panel[data-theme="dark"]  .divider{background:rgba(255,255,255,.10)}

        /* 登录模态框 */
        .login-modal{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.65);z-index:9999}
        .login-card{border-radius:16px;padding:24px;min-width:320px;max-width:90vw;}
        #panel[data-theme="light"] .login-card{background:rgba(248,250,252,.95); color:#0f172a; border:1px solid rgba(15,23,42,.08)}
        #panel[data-theme="dark"] .login-card{background:rgba(11,18,32,.95); color:#e5edff; border:1px solid rgba(255,255,255,.12)}
        .login-card h2{margin:0 0 20px 0;text-align:center}
        .login-card .input-group{margin-bottom:16px}
        .login-card label{display:block;margin-bottom:6px;font-size:13px;font-weight:600}
        .login-card input[type="text"],
        .login-card input[type="password"]{width:100%;border-radius:8px;padding:10px 12px;font-size:14px;box-sizing:border-box}
        .login-card button{width:100%;margin-top:8px}
        .login-error{color:#ef4444;font-size:12px;margin-top:8px;text-align:center}
        
        /* 用户信息显示 */
        .user-info{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding:10px;border-radius:10px}
        #panel[data-theme="light"] .user-info{background:rgba(255,255,255,.45)}
        #panel[data-theme="dark"] .user-info{background:rgba(13,21,36,.45)}
        .user-name{font-weight:600;display:flex;align-items:center;gap:6px}
        .user-logout{background:#64748b;padding:4px 10px;font-size:12px;border-radius:6px;cursor:pointer;border:none;color:#fff}
        .user-quota{font-size:12px;opacity:.8;margin-top:4px}

        /* Toggle switch */
        .switch{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none}
        .switch input{appearance:none;width:42px;height:24px;border-radius:999px;position:relative;outline:none;transition:.2s;}
        #panel[data-theme="light"] .switch input{background:#cbd5e1;}
        #panel[data-theme="dark"]  .switch input{background:#334155;}
        #panel[data-theme="light"] .switch input:checked{background:#2563eb;}
        #panel[data-theme="dark"]  .switch input:checked{background:#2563eb;}
        .switch input::after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;background:#fff;border-radius:50%;transition:.2s;}
        .switch input:checked::after{left:21px;}

        .kv{display:flex;align-items:center;gap:8px}
        .range{flex:1}
        input[type="range"]{width:180px}
        button{background:#2563eb;color:#fff;border:0;border-radius:10px;padding:6px 12px;cursor:pointer}
        button.muted{background:#64748b}
        details{border-radius:12px; padding:8px 10px}
        #panel[data-theme="light"] details{border:1px solid rgba(15,23,42,.08); background:rgba(255,255,255,.35)}
        #panel[data-theme="dark"]  details{border:1px solid rgba(255,255,255,.12); background:rgba(13,21,36,.35)}
        details > summary{cursor:pointer; list-style:none; outline:none}
        details > summary::-webkit-details-marker{display:none}
        input[type="text"]{width:100%;border-radius:8px;padding:6px 8px}
        #panel[data-theme="light"] input[type="text"]{background:rgba(255,255,255,.65);color:#0f172a;border:1px solid rgba(15,23,42,.08)}
        #panel[data-theme="dark"]  input[type="text"]{background:#0e1626;color:#e5edff;border:1px solid rgba(255,255,255,.12)}

        a{color:#2563eb;text-decoration:underline}

        /* 徽章样式 */
        .badge{padding:2px 8px;border-radius:999px;font-size:12px;margin-left:6px;opacity:.8;border:1px solid currentColor}
        .badge-pro{background:#7c3aed;color:#fff;border-color:#7c3aed}
        .badge-plus{background:#eab308;color:#fff;border-color:#eab308}
        .badge-free{background:#64748b;color:#fff;border-color:#64748b}

        /* About modal */
        .modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.45);}
        .modal .card{border-radius:14px;padding:16px 18px;min-width:300px;max-width:90vw;text-align:center}
        #panel[data-theme="light"] .modal .card{background:rgba(248,250,252,.9); color:#0f172a; border:1px solid rgba(15,23,42,.08)}
        #panel[data-theme="dark"]  .modal .card{background:rgba(11,18,32,.92); color:#e5edff; border:1px solid rgba(255,255,255,.12)}
        .close{position:absolute;top:10px;right:12px;background:transparent;border:0;font-size:18px;cursor:pointer}
        
        /* 确认对话框 */
        .confirm-modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.55);z-index:10000}
        .confirm-card{border-radius:14px;padding:20px;min-width:280px;text-align:center}
        #panel[data-theme="light"] .confirm-card{background:rgba(248,250,252,.95); color:#0f172a; border:1px solid rgba(15,23,42,.08)}
        #panel[data-theme="dark"] .confirm-card{background:rgba(11,18,32,.95); color:#e5edff; border:1px solid rgba(255,255,255,.12)}
        .confirm-buttons{display:flex;gap:10px;margin-top:16px;justify-content:center}
        .confirm-buttons button{padding:8px 20px;min-width:80px}
        
        /* 功能锁定样式 */
        .feature-locked{position:relative;opacity:.5;pointer-events:none}
        .feature-locked::after{content:"🔒 Plus+";position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,.75);color:#fff;padding:4px 12px;border-radius:6px;font-size:12px;white-space:nowrap}
        .tier-hint{font-size:11px;opacity:.7;margin-top:4px;color:#eab308}
      </style>

      <!-- 登录模态框 -->
      <div class="login-modal" id="loginModal" style="display:none">
        <div class="login-card">
          <h2>Divesee 登录</h2>
          <div class="input-group">
            <label>用户名</label>
            <input id="loginUsername" type="text" placeholder="请输入用户名">
          </div>
          <div class="input-group">
            <label>密码</label>
            <input id="loginPassword" type="password" placeholder="请输入密码">
          </div>
          <button id="loginSubmit">登录</button>
          <div class="login-error" id="loginError" style="display:none"></div>
        </div>
      </div>

      <!-- 退出确认对话框 -->
      <div class="confirm-modal" id="logoutConfirm">
        <div class="confirm-card">
          <h3 style="margin:0 0 12px 0">确认退出登录？</h3>
          <p style="margin:0;opacity:.8">退出后将清除所有数据</p>
          <div class="confirm-buttons">
            <button id="logoutCancel" class="muted">取消</button>
            <button id="logoutConfirmBtn">确认退出</button>
          </div>
        </div>
      </div>

      <!-- 用户信息区 -->
      <div class="user-info" id="userInfo" style="display:none">
        <div>
          <div class="user-name">
            <span id="userName"></span>
            <span class="badge" id="userBadge"></span>
          </div>
          <div class="user-quota" id="userQuota"></div>
        </div>
        <button class="user-logout" id="logoutBtn">退出</button>
      </div>

      <div class="title">Divesee潜读<span class="badge">v0.4.2</span></div>

      <div class="row">
        <label class="switch"><input id="modeImmersive" type="checkbox"><span class="lab">本地算法</span></label>
        <label class="switch"><input id="modeAI" type="checkbox"><span class="lab">在线算法</span></label>
      </div>

      <div class="row">
        <label class="switch"><input id="enabledByDefault" type="checkbox"><span class="lab">默认开启本地算法</span></label>
      </div>

      <div class="divider"></div>

      <div class="group">
        <div class="row kv"><span>字号</span><input id="fontSizeStep" class="range" type="range" min="-8" max="8"><span id="fontSizeVal">0px</span></div>
        <div class="row kv"><span>行距</span><input id="lineHeight" class="range" type="range" min="1.2" max="2.4" step="0.1"><span id="lineHeightVal">1.8</span></div>
        <div class="row">
          <label class="switch"><input id="darkTheme" type="checkbox"><span class="lab">深色主题</span></label>
          <label class="switch"><input id="twoColumn" type="checkbox"><span class="lab">双栏阅读</span></label>
        </div>
        <div class="row">
          <label class="switch"><input id="focusMode" type="checkbox"><span class="lab">专注模式</span></label>
        </div>
      </div>

      <div class="divider"></div>

      <div class="group">
        <div class="row"><span>阅读设置</span></div>
        <div class="row">
          <label class="switch"><input id="aiHighlightMain" type="checkbox"><span class="lab">高亮全文主旨</span></label>
          <label class="switch"><input id="aiMarkParagraphTopics" type="checkbox"><span class="lab">标记段落主题</span></label>
        </div>
        <div class="row">
          <label class="switch"><input id="aiHighlightKeywords" type="checkbox"><span class="lab">高亮关键词</span></label>
        </div>
        <div class="hint">提示：AI 模式仅在刷新本页或强制刷新调用；如还原无反应则请手动刷新清屏（测试：无声阅读）。</div>
      </div>

      <div class="divider"></div>

      <div class="group" id="silentReadingSection">
        <div class="row"><span>无声阅读</span><span class="tier-hint" id="silentReadingHint" style="display:none">需要 Plus 或 Pro 版本</span></div>
        <div class="row kv">
          <span>速度（字/分钟）</span>
          <input id="wpm" class="range" type="range" min="320" max="800" step="10" value="480">
          <span id="wpmVal">480</span>
        </div>
        <div class="row" style="gap:0.6rem; justify-content: center;" id="silentReadingControls">
          <button id="silentStart" class="dr-silent-btn" title="开始">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </button>
          <button id="silentPause" class="dr-silent-btn" title="暂停">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/>
            </svg>
          </button>
          <button id="silentStop" class="dr-silent-btn" title="停止">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <rect x="6" y="6" width="12" height="12"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="divider"></div>

      <details id="advanced">
        <summary>设置</summary>
        <div class="row">
          <span class="hint">API 端点</span>
        </div>
        <div class="row">
          <input id="apiEndpoint" type="text" placeholder="https://api.divesee.com:9443">
        </div>
        <div class="row" style="font-size:12px;opacity:.8">
          © Divesee Team · Demo <a id="aboutLink" href="javascript:void(0)">About</a>
        </div>
      </details>

      <div class="row" style="justify-content:space-between;margin-top:12px;align-items:center">
        <div style="font-size:12px;opacity:.8" id="quotaInfo"></div>
        <div style="display:flex;gap:8px">
          <button id="force" class="">强制刷新</button>
          <button id="apply">更新</button>
          <button id="reset" class="muted">还原</button>
        </div>
      </div>

      <div class="modal" id="aboutModal" aria-hidden="true">
        <div class="card" role="dialog" aria-modal="true">
          <button class="close" id="aboutClose">×</button>
          <h3>About Us</h3>
          <p>DiveSee Team · All Rights Reserved</p>
          <p><a target="_blank" rel="noopener" href="https://www.divesee.com/About">www.divesee.com/About</a></p>
          <p>6 students team</p>
          <p>v0.4.2</p>
        </div>
      </div>
    `;
    shadow.appendChild(panel);

    // ========= State & Binding =========
    // ========= 登录鉴权系统 =========
    const users = {
      'free_test': { password: 'divesee123', tier: 'free', quota: 5 },
      'plus_test': { password: 'divesee123', tier: 'plus', quota: 500 },
      'pro_test': { password: 'divesee123', tier: 'pro', quota: Infinity }
    };

    let currentUser = null;
    let usageCount = 0;

    const loginModal = panel.querySelector('#loginModal');
    const loginUsername = panel.querySelector('#loginUsername');
    const loginPassword = panel.querySelector('#loginPassword');
    const loginSubmit = panel.querySelector('#loginSubmit');
    const loginError = panel.querySelector('#loginError');
    const userInfo = panel.querySelector('#userInfo');
    const userName = panel.querySelector('#userName');
    const userBadge = panel.querySelector('#userBadge');
    const userQuota = panel.querySelector('#userQuota');
    const logoutBtn = panel.querySelector('#logoutBtn');
    const logoutConfirm = panel.querySelector('#logoutConfirm');
    const logoutCancel = panel.querySelector('#logoutCancel');
    const logoutConfirmBtn = panel.querySelector('#logoutConfirmBtn');
    const quotaInfo = panel.querySelector('#quotaInfo');

    // 检查登录状态
    function checkLoginState() {
      const savedUser = localStorage.getItem('divesee_user');
      const savedUsage = localStorage.getItem('divesee_usage');
      
      if (savedUser) {
        try {
          currentUser = JSON.parse(savedUser);
          usageCount = parseInt(savedUsage) || 0;
          
          // Pro 用户恢复 Infinity
          if (currentUser.tier === 'pro') {
            currentUser.maxQuota = Infinity;
          }
          
          showUserInfo();
        } catch (e) {
          console.error('[Login] 恢复用户信息失败:', e);
          showLoginModal();
        }
      } else {
        showLoginModal();
      }
    }

    // 显示登录弹窗
    function showLoginModal() {
      loginModal.style.display = 'flex';
      loginError.style.display = 'none';
      loginUsername.value = '';
      loginPassword.value = '';
      userInfo.style.display = 'none';
      quotaInfo.textContent = '';
      updateFeatureAccess(); // 更新功能访问权限（锁定所有高级功能）
    }

    // 隐藏登录弹窗
    function hideLoginModal() {
      loginModal.style.display = 'none';
    }

    // 显示用户信息
    function showUserInfo() {
      userInfo.style.display = 'flex';
      userName.textContent = currentUser.username;
      
      // 设置徽章样式
      const tierMap = {
        'free': { text: 'Free', class: 'badge-free' },
        'plus': { text: 'Plus', class: 'badge-plus' },
        'pro': { text: 'Pro', class: 'badge-pro' }
      };
      
      const tierInfo = tierMap[currentUser.tier] || tierMap.free;
      userBadge.textContent = tierInfo.text;
      userBadge.className = 'badge ' + tierInfo.class;
      
      updateQuotaDisplay();
      updateFeatureAccess(); // 更新功能访问权限
      hideLoginModal();
    }

    // 更新配额显示
    function updateQuotaDisplay() {
      if (!currentUser) return;
      
      const remaining = currentUser.maxQuota === Infinity 
        ? '∞' 
        : Math.max(0, currentUser.maxQuota - usageCount);
      
      // 更新用户信息区域的配额
      if (currentUser.maxQuota === Infinity) {
        userQuota.textContent = '无限次调用';
      } else {
        userQuota.textContent = `剩余 ${remaining} / ${currentUser.maxQuota} 次调用`;
      }
      
      // 更新底部配额信息
      if (currentUser.maxQuota === Infinity) {
        quotaInfo.textContent = '∞ 剩余';
      } else {
        quotaInfo.textContent = `${remaining} 次剩余`;
      }
    }

    // 检查配额
    function checkQuota() {
      if (!currentUser) {
        alert('请先登录！');
        return false;
      }
      
      if (usageCount >= currentUser.maxQuota) {
        alert('调用次数已用完！请升级套餐或联系客服。');
        return false;
      }
      
      return true;
    }

    // 扣除配额
    function consumeQuota() {
      if (!currentUser) return;
      
      usageCount++;
      localStorage.setItem('divesee_usage', usageCount.toString());
      updateQuotaDisplay();
    }

    // 更新功能访问权限
    function updateFeatureAccess() {
      const silentReadingControls = panel.querySelector('#silentReadingControls');
      const silentReadingHint = panel.querySelector('#silentReadingHint');
      
      if (!currentUser) {
        // 未登录，锁定功能
        silentReadingControls.classList.add('feature-locked');
        silentReadingHint.style.display = 'inline-block';
        return;
      }
      
      // 根据用户等级控制功能访问
      if (currentUser.tier === 'free') {
        // Free 用户：锁定无声阅读
        silentReadingControls.classList.add('feature-locked');
        silentReadingHint.style.display = 'inline-block';
      } else {
        // Plus 和 Pro 用户：解锁
        silentReadingControls.classList.remove('feature-locked');
        silentReadingHint.style.display = 'none';
      }
    }

    // 检查功能权限
    function checkFeatureAccess(feature) {
      if (!currentUser) {
        alert('请先登录！');
        return false;
      }
      
      if (feature === 'silentReading') {
        if (currentUser.tier === 'free') {
          alert('无声阅读功能需要 Plus 或 Pro 版本\n\n请升级您的套餐以使用此功能。');
          return false;
        }
      }
      
      return true;
    }

    // 登录提交
    loginSubmit.onclick = () => {
      const username = loginUsername.value.trim();
      const password = loginPassword.value.trim();
      
      if (!username || !password) {
        loginError.textContent = '请输入用户名和密码';
        loginError.style.display = 'block';
        return;
      }
      
      if (users[username] && users[username].password === password) {
        // 登录成功
        const user = users[username];
        currentUser = {
          username: username,
          tier: user.tier,
          maxQuota: user.quota
        };
        
        usageCount = 0;
        
        // 保存到 localStorage
        localStorage.setItem('divesee_user', JSON.stringify(currentUser));
        localStorage.setItem('divesee_usage', '0');
        
        showUserInfo();
        loginError.style.display = 'none';
      } else {
        // 登录失败
        loginError.textContent = '用户名或密码错误';
        loginError.style.display = 'block';
      }
    };

    // 登录框回车提交
    loginPassword.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        loginSubmit.click();
      }
    });

    // 退出登录
    logoutBtn.onclick = () => {
      logoutConfirm.style.display = 'flex';
    };

    logoutCancel.onclick = () => {
      logoutConfirm.style.display = 'none';
    };

    logoutConfirmBtn.onclick = () => {
      // 清除数据
      localStorage.removeItem('divesee_user');
      localStorage.removeItem('divesee_usage');
      currentUser = null;
      usageCount = 0;
      
      // 显示登录界面
      logoutConfirm.style.display = 'none';
      showLoginModal();
    };

    // 初始化登录状态
    checkLoginState();

    // 暴露给 API 的配额检查和消耗函数
    window.DeepReadingAPI.checkQuota = checkQuota;
    window.DeepReadingAPI.consumeQuota = consumeQuota;

    // ========= State & Binding =========
    const state = api.state();
    const modeAI = panel.querySelector('#modeAI');
    const modeImm = panel.querySelector('#modeImmersive');

    if (state.enabled && S.aiEnabled) {
      modeAI.checked = true; modeImm.checked = false;
    } else if (state.enabled) {
      modeImm.checked = true; modeAI.checked = false;
    }

    panel.querySelector('#enabledByDefault').checked = !!S.enabledByDefault;
    panel.querySelector('#aiHighlightMain').checked = S.aiHighlightMain !== false;
    panel.querySelector('#aiMarkParagraphTopics').checked = S.aiMarkParagraphTopics !== false;
    panel.querySelector('#aiHighlightKeywords').checked = S.aiHighlightKeywords !== false;
    panel.querySelector('#apiEndpoint').value = S.apiEndpoint || "";
    panel.querySelector('#darkTheme').checked = (S.immersiveTheme || "normal")==="dark";
    
    // 字号初始化：优先使用保存值，否则自动检测页面字号
    let initialFontSize = 0;
    if (typeof S.fontSizeStep === 'number') {
      // 如果用户已设置过字号，使用设置值
      initialFontSize = S.fontSizeStep;
      console.log('[Font Size Init] 使用已保存的字号:', initialFontSize);
    } else {
      // 否则自动检测页面正文字号
      initialFontSize = api.getPageBaseFontSize();
      console.log('[Font Size Init] 自动检测到页面字号偏移:', initialFontSize);
      // 同步保存并应用检测到的初始值
      if (initialFontSize !== 0) {
        save({ fontSizeStep: initialFontSize }).catch(e => console.error('[Font Size Init] 保存失败:', e));
      }
    }
    
    panel.querySelector('#fontSizeStep').value = initialFontSize;
    panel.querySelector('#lineHeight').value = S.lineHeight || 1.8;
    panel.querySelector('#twoColumn').checked = !!S.twoColumn;
    panel.querySelector('#focusMode').checked = !!S.focusMode;
    panel.querySelector('#wpm').value = S.wpm || 480;
    
    // 更新显示文本：字号显示实际像素值（16 + 偏移量）
    const formatFontSizeDisplay = (val) => `${16 + Number(val)}px`;
    panel.querySelector('#fontSizeVal').textContent = formatFontSizeDisplay(initialFontSize);
    panel.querySelector('#lineHeightVal').textContent = (S.lineHeight||1.8).toString();
    panel.querySelector('#wpmVal').textContent = (S.wpm||480).toString();

    // 主题联动：面板玻璃/按钮玻璃
    const setPanelTheme = (theme)=>{ panel.setAttribute('data-theme', theme==='dark' ? 'dark':'light'); applyFabTheme(); };
    const applyFabTheme = ()=>{
      const dark = panel.getAttribute('data-theme') === 'dark';
      if (dark){
        fab.style.background = 'rgba(15,23,42,.50)';
        fab.style.color = '#e5edff';
        fab.style.border = '1px solid rgba(255,255,255,.12)';
      } else {
        fab.style.background = 'rgba(255,255,255,.55)';
        fab.style.color = '#0f172a';
        fab.style.border = '1px solid rgba(15,23,42,.08)';
      }
    };
    setPanelTheme((S.immersiveTheme || 'normal'));

    // 保存函数（需要在初始化代码之前定义）
    const save = async (payload)=>{
      const { settings } = await chrome.storage.sync.get("settings");
      await chrome.storage.sync.set({ settings: { ...(settings||{}), ...payload } });
      api.setSettings(payload);
    };

    // 总开关互斥
    modeImm.onchange = async (e)=>{
      if (e.target.checked) {
        modeAI.checked = false;
        await save({ aiEnabled:false, mode:"normal" });
        api.enable();
      } else {
        api.disable();
      }
    };
    modeAI.onchange = async (e)=>{
      if (e.target.checked) {
        modeImm.checked = false;
        await save({ aiEnabled:true, mode:"ai" });
        api.enable();
        api.rerenderFromCache();
      } else {
        await save({ aiEnabled:false, mode:"normal" });
        api.disable();
      }
    };

    // 即调即用：range 与开关
    const range = (id, key)=>{
      const el = panel.querySelector(id);
      const outIdMap = {
        '#fontSizeStep': '#fontSizeVal',
        '#lineHeight':  '#lineHeightVal',
        '#wpm':         '#wpmVal'
      };
      const out = panel.querySelector(outIdMap[id] || (id + 'Val'));
      
      if (!el) {
        console.error(`[Range Error] 找不到输入元素: ${id}`);
        return;
      }
      if (!out) {
        console.error(`[Range Error] 找不到输出元素: ${outIdMap[id] || (id + 'Val')}`);
        return;
      }
      
      console.log(`[Range Init] ${key} 初始化完成，当前值:`, el.value);
      
      const updateValue = async ()=>{
        const v = (key === "fontSizeStep" ? Math.round(+el.value) : +el.value);
        console.log(`[Range Update] ${key} 更新为: ${v}`);
        
        // 更新显示文本
        if (key === "fontSizeStep") {
          // 显示实际字号（16 + 偏移量）
          out.textContent = `${16 + v}px`;
          console.log(`[Font Size] 显示文本更新为: "${16 + v}px"`);
        } else if (key === "lineHeight") {
          out.textContent = v.toFixed(1);
        } else {
          out.textContent = `${v}`;
        }
        
        // 保存到存储
        const patch = {}; 
        patch[key] = v;
        await save(patch);
        
        // 字号改变时立即应用样式
        if (key === 'fontSizeStep') {
          const html = document.documentElement;
          if (v !== 0) {
            html.style.fontSize = `calc(100% + ${v}px)`;
            console.log(`[Font Size] 应用样式: calc(100% + ${v}px)`);
          } else {
            html.style.fontSize = "";
            console.log(`[Font Size] 重置样式`);
          }
        }
      };
      
      // 监听 input 事件实现实时更新
      el.addEventListener('input', updateValue);
      // 监听 change 事件作为兜底
      el.addEventListener('change', updateValue);
      
      console.log(`[Range Init] ${key} 事件监听器已绑定`);
    };
    
    range('#fontSizeStep','fontSizeStep');
    range('#lineHeight','lineHeight');
    range('#wpm','wpm');

    const bindSwitch = (sel, key)=>{
      const el = panel.querySelector(sel);
      el.onchange = async ()=>{
        const patch={}; patch[key]=el.checked;
        await save(patch);
        
        // 语义核心提取的3个开关：无论AI还是本地模式都重新渲染
        if (key === 'aiHighlightMain' || key === 'aiMarkParagraphTopics' || key === 'aiHighlightKeywords') {
          api.rerenderFromCache();
        }
      };
    };
    bindSwitch('#enabledByDefault', 'enabledByDefault');
    bindSwitch('#twoColumn', 'twoColumn');
    bindSwitch('#focusMode', 'focusMode');
    bindSwitch('#aiHighlightMain', 'aiHighlightMain');
    bindSwitch('#aiMarkParagraphTopics', 'aiMarkParagraphTopics');
    bindSwitch('#aiHighlightKeywords', 'aiHighlightKeywords');

    // 主题切换：联动玻璃风格
    panel.querySelector('#darkTheme').addEventListener('change', async (e)=>{
      const theme = e.target.checked ? 'dark' : 'normal';
      await save({ immersiveTheme: theme });
      setPanelTheme(theme);
    });

    // API endpoint（隐藏在设置里）
    panel.querySelector('#apiEndpoint').addEventListener('change', async (e)=>{
      await save({ apiEndpoint: e.target.value.trim() });
    });

    // 应用 / 还原
    panel.querySelector('#apply').onclick = ()=> api.update();
    panel.querySelector('#force').onclick = ()=> api.forceRefresh();
    panel.querySelector('#reset').onclick = ()=> api.reset();

    // About modal
    const modal = panel.querySelector('#aboutModal');
    const openAbout = ()=>{ modal.style.display='flex'; modal.setAttribute('aria-hidden','false'); };
    const closeAbout = ()=>{ modal.style.display='none'; modal.setAttribute('aria-hidden','true'); };
    panel.querySelector('#aboutLink').onclick = openAbout;
    panel.querySelector('#aboutClose').onclick = closeAbout;

    // 显隐
    const togglePanel = ()=>{
      const isOpen = panel.style.display!=='none';
      panel.style.display = isOpen ? 'none' : 'block';
      if (!isOpen) placePanelByCorner();
    };
    fab.addEventListener('click', (e)=>{
      e.stopPropagation();
      togglePanel();
    });
    document.addEventListener('mousedown', (e)=>{
      const path = e.composedPath();
      if (panel.style.display!=='none' && !path.includes(root)) panel.style.display = 'none';
    }, true);

    // 拖拽 + 吸附 + 展开方向
    let drag = null;
    const startDrag = (ev)=>{
      if (ev.button !== 0) return;
      ev.preventDefault();
      ev.stopPropagation();
      const rect = fab.getBoundingClientRect();
      drag = { sx:rect.left, sy:rect.top, x:ev.clientX, y:ev.clientY };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', endDrag);
    };
    const onMove = (e)=>{
      if (!drag) return;
      const nx = drag.sx + (e.clientX - drag.x);
      const ny = drag.sy + (e.clientY - drag.y);
      fab.style.left = clamp(nx, 8, window.innerWidth-56) + 'px';
      fab.style.top  = clamp(ny, 8, window.innerHeight-56) + 'px';
      fab.style.bottom = 'auto'; fab.style.right='auto';
    };
    const endDrag = ()=>{
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', endDrag);
      drag = null;
      snapToCorner();
      placePanelByCorner();
    };
    fab.addEventListener('mousedown', startDrag);
    function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }

    let corner = "TR"; // 默认右上（向左下展开）
    function detectCorner(){
      const r = fab.getBoundingClientRect();
      const cx = r.left + r.width/2;
      const cy = r.top + r.height/2;
      const left = cx < window.innerWidth/2;
      const top = cy < window.innerHeight/2;
      return (top && left) ? "TL" : (top && !left) ? "TR" : (!top && left) ? "BL" : "BR";
    }
    function snapToCorner(){
      corner = detectCorner();
      const pad = 24;
      if (corner==="BL"){ fab.style.left = pad+'px'; fab.style.bottom = pad+'px'; fab.style.top='auto'; fab.style.right='auto'; }
      if (corner==="TL"){ fab.style.left = pad+'px'; fab.style.top = pad+'px'; fab.style.bottom='auto'; fab.style.right='auto'; }
      if (corner==="BR"){ fab.style.right = pad+'px'; fab.style.bottom = pad+'px'; fab.style.left='auto'; fab.style.top='auto'; }
      if (corner==="TR"){ fab.style.right = pad+'px'; fab.style.top = pad+'px'; fab.style.left='auto'; fab.style.bottom='auto'; }
    }
    function placePanelByCorner(){
      const r = fab.getBoundingClientRect();
      panel.style.left = panel.style.right = panel.style.top = panel.style.bottom = 'auto';
      const gap = 12;
      if (corner==="BL"){ // 向右上展开
        panel.style.left = r.left + 'px';
        panel.style.bottom = (window.innerHeight - r.top + gap) + 'px';
      }
      if (corner==="TL"){ // 向右下展开
        panel.style.left = r.left + 'px';
        panel.style.top = (r.bottom + gap) + 'px';
      }
      if (corner==="BR"){ // 向左上展开
        panel.style.right = (window.innerWidth - r.right) + 'px';
        panel.style.bottom = (window.innerHeight - r.top + gap) + 'px';
      }
      if (corner==="TR"){ // 向左下展开
        panel.style.right = (window.innerWidth - r.right) + 'px';
        panel.style.top = (r.bottom + gap) + 'px';
      }
    }
    snapToCorner();

    // Esc 关闭
    document.addEventListener('keydown', (e)=>{
      if (e.key === 'Escape' && panel.style.display!=='none') panel.style.display='none';
    });

    // 无声阅读控制按钮
    panel.querySelector('#silentStart').onclick = () => {
      if (!checkFeatureAccess('silentReading')) return;
      if (api.silentReading) {
        api.silentReading.start();
      }
    };
    
    panel.querySelector('#silentPause').onclick = () => {
      if (!checkFeatureAccess('silentReading')) return;
      if (api.silentReading) {
        api.silentReading.pause();
      }
    };
    
    panel.querySelector('#silentStop').onclick = () => {
      if (!checkFeatureAccess('silentReading')) return;
      if (api.silentReading) {
        api.silentReading.stop();
      }
    };
  }
})();